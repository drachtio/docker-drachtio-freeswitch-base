//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_result_base.h>
#include <vision_api_cxx_session_result_properties.h>
#include <vision_api_cxx_session_result_property.h>
#include <vision_api_cxx_session_result_reason.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Session {
namespace Results {

/// <summary>
/// Represents the output an AI inteferening operation (e.g. detection, recognition, prediction, ...).
/// </summary>
class SessionResult : private Core::Details::ResultBase<SessionResultReason, SessionResultProperty, SessionResultProperties>
{
private:

    using BaseResult = ResultBase<SessionResultReason, SessionResultProperty, SessionResultProperties>;

public:

    /// <summary>
    /// Destructs an instance of the SessionResult class.
    /// </summary>
    ~SessionResult() = default;

    /// <summary>
    /// Gets the unique id for the Session from which this SessionResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    std::string GetSessionId() const { return BaseResult::GetSessionId(); }

    /// <summary>
    /// Gets the unique id for the Session from which this SessionResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    template<class T = std::string> 
    AI::Core::Details::enable_if_w_or_string_t<T> GetSessionId() const { return BaseResult::GetSessionId<T>(); }

    /// <summary>
    /// Gets the unique SessionResult ID for this SessionResult.
    /// </summary>
    /// <returns>
    /// The unique SessionResult Id string.
    /// </returns>
    std::string GetResultId() const { return BaseResult::GetResultId(); }

    /// <summary>
    /// Gets the unique SessionResult ID for this SessionResult.
    /// </summary>
    /// <returns>
    /// The unique SessionResult Id string.
    /// </returns>
    template<class T = std::string> 
    AI::Core::Details::enable_if_w_or_string_t<T> GetResultId() const { return BaseResult::GetResultId<T>(); }

    /// <summary>
    /// Gets the SessionResultReason for generation of this result.
    /// </summary>
    SessionResultReason GetReason() const { return BaseResult::GetReason(SessionResultReason::NoMatch, SessionResultReason::Recognized); }

    /// <summary>
    /// Gets a collection of additional inferencing operation properties.
    /// </summary>
    const SessionResultProperties& Properties;

protected:

    static std::shared_ptr<SessionResult> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new SessionResult(handle);
        return std::shared_ptr<SessionResult>(ptr);
    }

    explicit SessionResult(AZAC_HANDLE result) :
        ResultBase(result),
        Properties(GetProperties())
    {
    }

    explicit operator AZAC_HANDLE() { return AI::Core::Details::ProtectedAccess<BaseResult>::HandleFromPtr(this); }

private:

    AZAC_DISABLE_DEFAULT_CTORS(SessionResult);
};

} } } } } } // Azure::AI::Vision::Core::Session::Results
