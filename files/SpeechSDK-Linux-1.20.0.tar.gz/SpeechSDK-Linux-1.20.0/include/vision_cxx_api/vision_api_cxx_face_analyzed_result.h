//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_json.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_result_base.h>
#include <vision_api_cxx_face_result_properties.h>
#include <vision_api_cxx_face_result_property.h>
#include <vision_api_cxx_face_result_reason.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Face {
namespace Results {

/// <summary>
/// Two-dimensional integer rectangle, expressed in pixels.
/// </summary>
struct Rect2DInt
{
    int64_t Left = 0, Top = 0;
    int64_t Width = 0, Height = 0;
};

/// <summary>
/// Landmark on detected face, with name and location.
/// </summary>
struct Landmark
{
    std::string Name;
    double X = 0;
    double Y = 0;
};

/// <summary>
/// The Euler angles (in degrees) describing the pose of the face detected.<pre>
/// // 3x3 rotation matrix, coeff:
///     float fPitchc = static_cast<float>(cos(Pitch));
///     float fPitchs = static_cast<float>(sin(Pitch));
///     float fYawc = static_cast<float>(cos(Yaw));
///     float fYaws = static_cast<float>(sin(Yaw));
///     float fRollc = static_cast<float>(cos(Roll));
///     float fRolls = static_cast<float>(sin(Roll));
///     coeff[0][0] = fYawc * fRollc;
///     coeff[0][1] = -fPitchc * fRolls + fPitchs * fYaws * fRollc;
///     coeff[0][2] = fPitchs * fRolls + fPitchc * fYaws * fRollc;
///     coeff[1][0] = fYawc * fRolls;
///     coeff[1][1] = fPitchc * fRollc + fPitchs * fYaws * fRolls;
///     coeff[1][2] = -fPitchs * fRollc + fPitchc * fYaws * fRolls;
///     coeff[2][0] = -fYaws;
///     coeff[2][1] = fPitchs * fYawc;
///     coeff[2][2] = fPitchc * fYawc;
/// </pre></summary>
struct HeadPose
{
    float Pitch = 0;
    float Yaw = 0;
    float Roll = 0;
};

/// <summary>
/// The possible outcomes of attempting to recognize a face.  
/// </summary>
enum class RecognitionStatus
{
    NotComputed,
    Failed,
    NotRecognized,
    Recognized
};

/// <summary>
/// If recognition failed, this enum details why.
/// </summary>
enum class RecognitionFailureReason
{
    None,
    GenericFailure,
    FaceNotFrontal,
    FaceEyeRegionNotVisible,
    ExcessiveFaceBrightness,
    ExcessiveImageBlurDetected
};

/// <summary>
/// If NotRecognized, that means the recognition effort reached a maximum number of attempts or timeout;
/// this enum differentiates what happened.
/// </summary>
enum class NotRecognizedReason
{
    None,
    MaxAttemptsReached,
    TimedOut,
};

/// <summary>
/// Result of recognizing the identity of a face and confidence.
/// </summary>
struct RecognitionResult
{
    std::string RecognizedIdentifier;
    float Confidence;
    RecognitionStatus Status;
    RecognitionFailureReason FailureReason;
    NotRecognizedReason NotRecoReason;
};

/// <summary>
/// Liveness status of person in video, indicating they appear to be alive and real
/// or a spoof that isn't a live person.  
/// </summary>
enum class LivenessStatus
{
    NotComputed,
    Failed,
    Live,
    Spoof
};

/// <summary>
/// Reasons for failure of the liveness analysis.
/// </summary>
enum class LivenessFailureReason
{
    None,
    GenericFailure,
    FaceMouthRegionNotVisible,
    FaceEyeRegionNotVisible,
    ExcessiveImageBlurDetected,
    ExcessiveFaceBrightness,
    FaceWithMaskDetected,
    ActionNotPerformed,
    TimedOut
};

/// <summary>
/// Result of liveness analysis with confidence.
/// </summary>
struct LivenessResult
{
    LivenessStatus Status;
    LivenessFailureReason FailureReason;
};

/// <summary>
/// Types of face masks detected.
/// </summary>
enum class MaskStatus
{
    NotComputed,
    NoMask,
    FaceMask,
    OtherMask
};

/// <summary>
/// Kind of face mask detected and confidence.
/// </summary>
struct MaskResult
{
    float Confidence;
    MaskStatus Status;
};

/// <summary>
/// Types of eyeglasses detected or none.
/// </summary>
enum class GlassStatus
{
    NotComputed,
    NoGlasses,
    ReadingGlasses,
    Sunglasses
};

/// <summary>
/// GlassResult represents the kind of eyeglasses were detected and the confidence.
/// </summary>
struct GlassResult
{
    float Confidence;
    GlassStatus Status;
};

/// <summary>
/// The AnalyzedResults struct aggregates attributes computed for a face, such as the
/// GlassResult and MaskResult.
/// </summary>
struct AnalyzedResults
{
    RecognitionResult Recognition;
    LivenessResult Liveness;
    MaskResult Mask;
    GlassResult Glass;
};

/// <summary>
/// FaceResults is an internal common base for the face results;
/// it holds the bounding box, UUID, pose, AnalyzedResults, and other
/// values for a face.  
/// </summary>
struct FaceResults
{
    std::string FaceUuid; // or guid?
    Rect2DInt BoundingBox;
    std::map<std::string, Landmark> Landmarks;
    HeadPose Pose;
    AnalyzedResults Results;

    std::map<std::string, std::string> Properties;

    /// <summary>
    /// Parse face analysis result in Json string to strongly-typed C++ structures.
    ///     std::shared_ptr<Face> faceptr = std::make_shared<AnalyzedFace>();
    ///     (*faceptr)->ParseFrom(...)
    /// </summary>
    /// <param name="jsonReaderFace"></param>Json string encoding face analyzer results.
    /// <returns></returns>
    FaceResults& ParseFrom(AI::Core::Details::Json::JsonValue jsonReaderFace)
    {
        FaceUuid = jsonReaderFace["UUID"].AsString();
        auto attributes = jsonReaderFace["Attributes"];
        for (int a = 0; a < attributes.Count(); ++a)
        {
            auto attribute = attributes[a];
            if (0 == attribute["QualityFilterFailureReason"].AsInt())
            {
                auto const result = attribute["Result"];
                std::string const type = attribute["Type"].AsString();
                if (type == "BoundingBox")
                {
                    BoundingBox.Left = result["Left"].AsInt();
                    BoundingBox.Top = result["Top"].AsInt();
                    BoundingBox.Width = result["Width"].AsInt();
                    BoundingBox.Height = result["Height"].AsInt();
                }
                else if (type == "FaceIdentity")
                {
                    Results.Recognition.Confidence = result["Confidence"].AsFloat();
                    Results.Recognition.RecognizedIdentifier = result["PersonId"].AsString();
                    std::string status(std::to_string(attribute["Status"].AsInt())); //status(attribute["Status"].AsString());
                    Results.Recognition.Status
                        = status == "0" /*OK*/ ? RecognitionStatus::Recognized
                        : status == "1" /*Error*/ ? RecognitionStatus::Failed
                        : status == "2" /*NotFound*/ ? RecognitionStatus::NotRecognized
                        : status == "3" /*MissingDependency*/ ? RecognitionStatus::Failed
                        : /*status == "4" QualityCheckFailed*/ RecognitionStatus::NotRecognized;
                }
                else if (type == "HeadPose")
                {
                    Pose.Pitch = result["Pitch"].AsFloat();
                    Pose.Yaw = result["Yaw"].AsFloat();
                    Pose.Roll = result["Roll"].AsFloat();
                }
                // else ...
            }
        }

        return *this;
    }
};


/// <summary>
/// AnalyzedFace holds the final face attributes computed.
/// An array of AnalyzedFace elements is the returned
/// after performing FaceAnalyer::AnalyzeOnce(), for example. 
/// </summary>
typedef FaceResults AnalyzedFace;


/// <summary>
/// Represents the output an AI inferencing operation (e.g. detection, recognition, prediction, ...).
/// </summary>
class FaceAnalyzedResult : public Core::Details::ResultBase<FaceResultReason, FaceResultProperty, FaceResultProperties>
{
private:

    using BaseResult = ResultBase<FaceResultReason, FaceResultProperty, FaceResultProperties>;

public:

    /// <summary>
    /// Destructs an instance of the FaceAnalyzedResult class.
    /// </summary>
    ~FaceAnalyzedResult() = default;

    /// <summary>
    /// Gets the Media/Frame/FrameSet position that generated this result.  Use the Media Source Reader to retrieve the input.
    /// </summary>
    /// <returns>
    /// The position associated with this result.
    /// </returns>
    uint64_t GetAssociatedMediaPosition() const { return BaseResult::GetAssociatedMediaPosition(); }

    /// <summary>
    /// Gets the FrameSet associated with this result.
    /// </summary>
    /// <returns>
    /// The FrameSet associated with this result.
    /// </returns>
    std::vector<std::shared_ptr<Input::Frames::Frame>> GetAssociatedFrameSet()
    {
        auto reader = BaseResult::GetAssociatedFrameSetReader();
        auto pos = GetAssociatedMediaPosition();

        return reader->ReadFrameSet(pos);
    }

    /// <summary>
    /// Gets the unique id for the Session from which this FaceAnalyzedResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    std::string GetSessionId() const { return BaseResult::GetSessionId(); }

    /// <summary>
    /// Gets the unique id for the Session from which this FaceAnalyzedResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    template<class T = std::string> 
    AI::Core::Details::enable_if_w_or_string_t<T> GetSessionId() const { return BaseResult::GetSessionId<T>(); }

    /// <summary>
    /// Gets the unique FaceAnalyzedResult ID for this FaceAnalyzedResult.
    /// </summary>
    /// <returns>
    /// The unique FaceAnalyzedResult Id string.
    /// </returns>
    std::string GetResultId() const { return BaseResult::GetResultId(); }

    /// <summary>
    /// Gets the unique FaceAnalyzedResult ID for this FaceAnalyzedResult.
    /// </summary>
    /// <returns>
    /// The unique FaceAnalyzedResult Id string.
    /// </returns>
    template<class T = std::string> 
    AI::Core::Details::enable_if_w_or_string_t<T> GetResultId() const { return BaseResult::GetResultId<T>(); }

    /// <summary>
    /// Gets the FaceResultReason for generation of this result.
    /// </summary>
    /// <returns>Reason for face result.</returns>
    FaceResultReason GetReason() const { return BaseResult::GetReason(FaceResultReason::NoMatch, FaceResultReason::Recognized); }

    /// <summary>
    /// Gets a collection of additional inferencing operation properties.
    /// </summary>
    const FaceResultProperties& Properties;

    /// <summary>
    /// Gets the tracked collection of faces with their current attributes
    /// </summary>
    /// <returns>Array of shared pointers to AnalyzedFace elements.</returns>
    std::vector<std::shared_ptr<AnalyzedFace>> GetFaces() const
    {
        auto insightsJson = Properties.Get(FaceResultProperty::Json);
        auto parsedFaces = AI::Core::Details::Json::JsonValue::Parse(insightsJson.c_str(), insightsJson.size());
        std::vector<std::shared_ptr<AnalyzedFace>> faces;
        for (int i = 0; i < parsedFaces.Count(); i++)
        {
            std::shared_ptr<AnalyzedFace> faceptr = std::make_shared<AnalyzedFace>();
            (*faceptr).ParseFrom(parsedFaces[i]);
            faces.push_back(faceptr);
        }

        return faces;
    }

protected:

    static std::shared_ptr<FaceAnalyzedResult> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new FaceAnalyzedResult(handle);
        return std::shared_ptr<FaceAnalyzedResult>(ptr);
    }

    explicit FaceAnalyzedResult(AZAC_HANDLE result) :
        ResultBase(result),
        Properties(GetProperties())
    {
    }

    explicit operator AZAC_HANDLE() { return AI::Core::Details::ProtectedAccess<BaseResult>::HandleFromPtr(this); }

private:

    AZAC_DISABLE_DEFAULT_CTORS(FaceAnalyzedResult);
};

} } } } } // Azure::AI::Vision::Face::Results
