//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//


AZAC_API_(bool) vision_frame_handle_is_valid(AZAC_HANDLE frame);

AZAC_API vision_frame_handle_release(AZAC_HANDLE frame);

AZAC_API__(const uint8_t *) vision_frame_get_data(AZAC_HANDLE frameHandle, size_t* sizeInBytes);
AZAC_API vision_frame_properties_handle_get(AZAC_HANDLE frameHandle, AZAC_HANDLE* framePropertiesHandle);
