//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_c_diagnostics.h>
#include <vision_api_cxx_common.h>
#include <string>
#include <sstream>
#include <iterator>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Diagnostics {
namespace Logging {

/// <summary>
/// Represents an log file.
/// </summary>
/// <remarks>Logging is a process wide construct.</remarks>
class FileLogger
{
public:
    /// <summary>
    /// Static class that controls file based logging.
    /// </summary>
    /// <param name="filePath">Path to log file</param>
    /// <param name="filters">Filters that will be applied to lines logged to the file.</param>
    static void Start(const char* filePath, std::initializer_list<const char*> filters = {})
    {
        Start(filePath, false, filters);
    }

    /// <summary>
    /// Static class that controls file based logging.
    /// </summary>
    /// <param name="filePath">Path to log file</param>
    /// <param name="filters">Filters that will be applied to lines logged to the file.</param>
    /// <param name="append">Whether or not any existing log file should be appended to.</param>
    static void Start(const char* filePath, bool append, std::initializer_list<const char*> filters = {})
    {
        auto props = PropertyCollection::Create();

        props->Set("SPEECH-LogFilename", filePath);

        std::ostringstream filtersCollapsed;
        std::copy(filters.begin(), filters.end(), std::ostream_iterator<std::string>(filtersCollapsed, ";"));

        props->Set("SPEECH-LogFileFilters", filtersCollapsed.str());
        props->Set("SPEECH-AppendToLogFile", append);

        AZAC_THROW_ON_FAIL(diagnostics_log_start_logging(ProtectedAccess< PropertyCollection>::HandleFromPtr(props.get()), nullptr));
    }

    /// <summary>
    /// Stops file logging.
    /// </summary>
    static void Stop()
    {
        AZAC_THROW_ON_FAIL(diagnostics_log_stop_logging());
    }

    /// <summary>
    /// Changes the filters that apply to file logging.
    /// </summary>
    /// <param name="filters">New filters, or null to remove the filters.</param>
    /// <remarks>When setting new filters there may be a turbulent period where no filters apply.</remarks>
    static void SetLogFilters(std::initializer_list<const char*> filters)
    {
        auto props = PropertyCollection::Create();

        std::ostringstream filtersCollapsed;
        std::copy(filters.begin(), filters.end(), std::ostream_iterator<std::string>(filtersCollapsed, ";"));

        props->Set("SPEECH-LogFileFilters", filtersCollapsed.str());
        AZAC_THROW_ON_FAIL(diagnostics_log_apply_properties(ProtectedAccess< PropertyCollection>::HandleFromPtr(props.get()), nullptr));
    }

private:
    template<typename Target> using ProtectedAccess = Azure::AI::Core::Details::ProtectedAccess<Target>;
    using PropertyCollection = AI::Core::Details::PropertyCollection<int>;
};

}}}}}}
