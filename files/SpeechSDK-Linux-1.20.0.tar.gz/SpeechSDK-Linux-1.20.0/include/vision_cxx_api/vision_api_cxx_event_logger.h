//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_c_diagnostics.h>
#include <vision_api_cxx_common.h>
#include <string>
#include <sstream>
#include <iterator>
#include <functional>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Diagnostics {
namespace Logging {

/// <summary>
/// Callback-based log target for the SDK.
/// </summary>
class EventLogger
{
public:
    using CallbackFunction_Type = ::std::function<void(const char* line)>;

    /// <summary>
    /// Sets the callback invoked for log messages.
    /// </summary>
    /// <param name="callback">callback function to call.</param>
    /// <remarks>This call is on the working thread in the SDK.</remarks>
    static void SetCallback(CallbackFunction_Type callback)
    {
        AZAC_THROW_ON_FAIL(diagnostics_logmessage_set_callback(nullptr == callback ? nullptr : LineLogged));

        SetOrGet(true, callback);
    }

    /// <summary>
    /// Sets filters for callbacks.
    /// </summary>
    /// <param name="filters">Filters to use</param>
    static void SetFilters(std::initializer_list<const char*> filters)
    {
        std::ostringstream filtersCollapsed;
        std::copy(filters.begin(), filters.end(), std::ostream_iterator<std::string>(filtersCollapsed, ";"));

        AZAC_THROW_ON_FAIL(diagnostics_logmessage_set_filters(filtersCollapsed.str().c_str()));
    }

private:
    static CallbackFunction_Type SetOrGet(bool set, CallbackFunction_Type callback)
    {
        static CallbackFunction_Type staticCallback = nullptr;
        if (set)
        {
            staticCallback = callback;
        }
        return staticCallback;
    }

    static void LineLogged(const char* line)
    {
        auto callback = SetOrGet(false, nullptr);
        if (nullptr != callback)
        {
            callback(line);
        }
    }
};
}}}}}}
