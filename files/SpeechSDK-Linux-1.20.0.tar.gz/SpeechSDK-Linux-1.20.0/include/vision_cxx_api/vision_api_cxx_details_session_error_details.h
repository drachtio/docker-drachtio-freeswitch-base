//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <string>
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_session_stopped_event_args.h>
#include <vision_api_c_event_args.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Details {

/// <summary>
/// Contains detailed information about why an error occurred
/// </summary>
template<typename TReason, typename TEventArgs, typename TDetails, typename TResult>
class SessionErrorDetails
{
private:

    template<typename Target> using ProtectedAccess = AI::Core::Details::ProtectedAccess<Target>;

    /// <summary>
    /// Enumeration for the error
    /// </summary>
    TReason m_reason;

    /// <summary>
    /// Error code
    /// </summary>
    int m_errorCode;

    /// <summary>
    /// Message with further information.
    /// </summary>
    std::string m_message;

public:

    /// <summary>
    /// Creates an instance of the correct ErrorDetails object from the event args.
    /// </summary>
    /// <param name="result">The result that was canceled.</param>
    /// <returns>A shared pointer to CancellationDetails.</returns>
    static std::shared_ptr<TDetails> FromEventArgs(const TEventArgs& args)
    {
        auto argsHandle = ProtectedAccess<TEventArgs>::HandleFromConstPtr(&args);
        AZAC_HANDLE propertiesHandle = AZAC_HANDLE_INVALID;
        AZAC_THROW_ON_FAIL(vision_event_args_properties_handle_get(argsHandle, &propertiesHandle));

        auto details = ProtectedAccess<TDetails>::FromHandle(propertiesHandle);
        return details;
    }

    /// <summary>
    /// Creates an instance of the correct ErrorDetails object from the event args.
    /// </summary>
    /// <param name="result">The result that was canceled.</param>
    /// <returns>A shared pointer to CancellationDetails.</returns>
    static std::shared_ptr<TDetails> FromResult(std::shared_ptr<TResult> result)
    {
        auto resultHandle = ProtectedAccess<TResult>::HandleFromPtr(result.get());
        AZAC_HANDLE propertiesHandle = AZAC_HANDLE_INVALID;
        AZAC_THROW_ON_FAIL(vision_result_properties_handle_get(resultHandle, &propertiesHandle));

        auto details = ProtectedAccess<TDetails>::FromHandle(propertiesHandle);
        return details;
    }

    /// <summary>
    /// Gets the reason for the error
    /// </summary>
    /// <returns></returns>
    TReason GetReason()
    {
        return m_reason;
    }

    /// <summary>
    /// Gets the error code
    /// </summary>
    int GetErrorCode()
    {
        return m_errorCode;
    }

    /// <summary>
    /// The error message in case of an unsuccessful recognition (<see cref="Reason"/> is set to Error).
    /// </summary>
    std::string GetMessage()
    {
        return m_message;
    }

    /// <summary>
    /// The error message in case of an unsuccessful recognition (<see cref="Reason"/> is set to Error).
    /// </summary>
    template<class T>
    AI::Core::Details::enable_if_w_or_string_t<T> GetMessage()
    {
        return AI::Core::Details::to_string<T>(m_message);
    }

protected:
    SessionErrorDetails(AZAC_HANDLE propsHandle)
    {
        auto properties2 = ProtectedAccess<AI::Core::Details::PropertyCollectionBase<int>>::FromHandle(propsHandle);
        m_message = properties2->Get("error.message");
        m_errorCode = std::stoi(properties2->Get("error.code", "0"));
        m_reason = (TReason)std::stoi(properties2->Get("error.reason", "0"));
    }
private:
    AZAC_DISABLE_DEFAULT_CTORS(SessionErrorDetails);
};

} } } } } // Azure::AI::Vision::Core::Details
