//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_frame.h>
#include <vision_api_c_frame_reader.h>

#include <vector>

namespace Azure {
namespace AI {
namespace Vision {
namespace Input {
namespace Frames {

/// <summary>
/// Represents the ability to read a FrameSet(s) of a set of frames adjacent in time
/// </summary>
class FrameSetReader
{
protected:
    template<typename Target> using ProtectedAccess = ::Azure::AI::Core::Details::ProtectedAccess<Target>;

public:
    /// <summary>
    /// Destructs an instance of the FrameSetReader class.
    /// </summary>
    virtual ~FrameSetReader()
    {
        if (vision_frame_reader_handle_is_valid(m_frameSetReader))
        {
            vision_frame_reader_handle_release(m_frameSetReader);
            m_frameSetReader = AZAC_HANDLE_INVALID;
        }
    };

    /// <summary>
    /// Reads a set of Frames of image data from the underlying FrameSetSource.
    /// </summary>
    std::vector<std::shared_ptr<Frame>> ReadFrameSet(uint64_t pos)
    {
        std::vector<std::shared_ptr<Frame>> frames;

        size_t frameSetSize = vision_frame_reader_get_frameset_size(m_frameSetReader);
        for (size_t i = 0; i < frameSetSize; ++i)
        {
            AZAC_HANDLE frameHandle = AZAC_HANDLE_INVALID;
            AZAC_IFTRUE_RETURN_X(AZAC_FAILED(vision_frame_reader_read_frame(m_frameSetReader, pos, static_cast<int>(i), &frameHandle)), {});
            frames.emplace_back(ProtectedAccess<Frame>::FromHandle(frameHandle));
        }

        return frames;
    }

protected:
    static std::shared_ptr<FrameSetReader> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new FrameSetReader(handle);
        return std::shared_ptr<FrameSetReader>(ptr);
    }

    explicit FrameSetReader(AZAC_HANDLE frameReader) :
        m_frameSetReader(frameReader)
    {
    }

    explicit operator AZAC_HANDLE() { return m_frameSetReader; }

private:
    AZAC_DISABLE_DEFAULT_CTORS(FrameSetReader);

    AZAC_HANDLE m_frameSetReader;
};

}
}
}
}
} // Azure::AI::Vision::Input::Frames
