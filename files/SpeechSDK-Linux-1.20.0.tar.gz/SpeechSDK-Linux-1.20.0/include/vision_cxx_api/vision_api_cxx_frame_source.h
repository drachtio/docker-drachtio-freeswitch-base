//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_frame_source_properties.h>
#include <vision_api_cxx_frame_source_property.h>
#include <vision_api_cxx_frame_format.h>
#include <vision_api_cxx_frame_writer.h>
#include <vision_api_c_frame_source.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Input {
namespace Frames {

/// <summary>
/// Represents a source of image frame data, used as input (or output) to (or from) Vision AI scenario operations.
/// </summary>
class FrameSource
{
protected:

    template<typename Target> using ProtectedAccess = ::Azure::AI::Core::Details::ProtectedAccess<Target>;
    AI::Core::Details::PropertyCollection<Frames::FrameSourceProperty, Frames::FrameSourceProperties> m_properties;

public:

    using CallbackFunction_Type = ::std::function<void(const std::shared_ptr<FrameWriter>& writer)>;

    /// <summary>
    /// Initializes a new instance of the FrameSource class.
    /// </summary>
    /// <param name="format">A FrameFormat obtained via FrameFormat::Create() or similar</param>
    /// <returns>The newly created FrameSource wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<FrameSource> FromFormat(const std::shared_ptr<FrameFormat>& format)
    {
        AZAC_HANDLE handle = AZAC_HANDLE_INVALID;
        AZAC_HANDLE formatHandle = ProtectedAccess<FrameFormat>::HandleFromPtr(format.get());

        AZAC_THROW_ON_FAIL(::vision_frame_source_handle_create(&handle, "adapter.streams.count", "1", formatHandle, "adapter.streams.0."));
        return FromHandle(handle);
    }

    /// <summary>
    /// Initializes a new instance of the FrameSource class.
    /// </summary>
    /// <param name="format">A FrameFormat obtained via FrameFormat::Create() or similar</param>
    /// <param name="callback">TODO</param>
    /// <returns>The newly created FrameSource wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<FrameSource> FromFormat(const std::shared_ptr<FrameFormat>& format, const CallbackFunction_Type callback)
    {
        AZAC_HANDLE handle = AZAC_HANDLE_INVALID;
        AZAC_HANDLE formatHandle = ProtectedAccess<FrameFormat>::HandleFromPtr(format.get());

        AZAC_THROW_ON_FAIL(::vision_frame_source_handle_create(&handle, "adapter.streams.count", "1", formatHandle, "adapter.streams.0."));
        return FromHandle(handle, callback);
    }

    /// <summary>
    /// Destructs an instance of the FrameSource class.
    /// </summary>
    virtual ~FrameSource()
    {
        if (vision_frame_source_handle_is_valid(m_frameSource))
        {
            ::vision_frame_source_handle_release(m_frameSource);
            m_frameSource = AZAC_HANDLE_INVALID;
        }
    };

    /// <summary>
    /// Gets the FrameWriter used to write frame data into this FrameSource object
    /// </summary>
    /// <returns>The FrameWriter used to write frame data, wrapped inside a std::shared_ptr</returns>
    std::shared_ptr<FrameWriter> GetWriter()
    {
        AZAC_HANDLE handle = AZAC_HANDLE_INVALID;
        AZAC_THROW_ON_FAIL(vision_frame_source_writer_handle_get(m_frameSource, &handle));
        return ProtectedAccess<FrameWriter>::FromHandle(handle);
    }

    /// <summary>
    /// Gets a collection of additional FrameSource properties.
    /// </summary>
    FrameSourceProperties& Properties;

protected:

    
    static std::shared_ptr<FrameSource> FromHandle(AZAC_HANDLE handle, CallbackFunction_Type callback = nullptr)
    {
        auto ptr = new FrameSource(handle, callback);
        return std::shared_ptr<FrameSource>(ptr);
    }

    explicit FrameSource(AZAC_HANDLE frameSource, CallbackFunction_Type callback) :
        m_properties(frameSource, [](auto handle, auto* properties) { return vision_frame_source_properties_handle_get(handle, properties); }),
        Properties(m_properties),
        m_frameSource(frameSource),
        m_callback(callback)
    {
        if (nullptr != m_callback)
        {
            vision_frame_source_callback_set(m_frameSource, this, FrameSource::NotifyCallback );
        }
    }

    explicit operator AZAC_HANDLE() { return m_frameSource; }

private:

    AZAC_DISABLE_DEFAULT_CTORS(FrameSource);

    AZAC_HANDLE m_frameSource;
    CallbackFunction_Type m_callback;

    static void NotifyCallback(AZAC_HANDLE handle, void* context)
    {
        UNUSED(handle);
        FrameSource *targetSource = (FrameSource*)context;
        targetSource->m_callback(targetSource->GetWriter());
    }

};

} } } } } // Azure::AI::Vision::Input::Frames
