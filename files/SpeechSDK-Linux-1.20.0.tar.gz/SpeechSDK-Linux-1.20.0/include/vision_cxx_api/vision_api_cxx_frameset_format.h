//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <initializer_list>
#include <memory>
#include <string>
#include <vector>
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_frame_format.h>
#include <vision_api_cxx_frameset_format_properties.h>
#include <vision_api_cxx_frameset_format_property.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Input {
namespace Frames {

/// <summary>
/// Represents a collection of image format properties (e.g. FOURCC, width, height, stride, ...)
/// </summary>
class FrameSetFormat
{
protected:

    template<typename Target> using ProtectedAccess = ::Azure::AI::Core::Details::ProtectedAccess<Target>;
    AI::Core::Details::PropertyCollection<Frames::FrameSetFormatProperty, Frames::FrameSetFormatProperties> m_properties;

public:
    static std::shared_ptr<FrameSetFormat> FromFormats(std::initializer_list<const std::shared_ptr<FrameFormat>> formats)
    {
        uint32_t i = 0;

        AZAC_HANDLE handle = AZAC_HANDLE_INVALID;
        AZAC_THROW_ON_FAIL(ai_core_properties_handle_create(&handle));
        AZAC_THROW_ON_FAIL(ai_core_properties_string_set(handle, 0, "adapter.streams.count", std::to_string(formats.size()).c_str()));

        for (auto format : formats)
        {
            auto targetNamespace = std::string("adapter.streams.");
            targetNamespace += std::to_string(i++);
            targetNamespace += ".";

            auto formatPropsHandle = ProtectedAccess<Frames::FrameFormatProperties>::HandleFromPtr(&format->Properties);
            AZAC_THROW_ON_FAIL(ai_core_properties_copy(formatPropsHandle, handle, targetNamespace.c_str()));
        }

        return FromHandle(handle);
    }

    static std::shared_ptr<FrameSetFormat> FromFormats(const std::vector<std::shared_ptr<FrameFormat>>& formats)
    {
        uint32_t i = 0;

        AZAC_HANDLE handle = AZAC_HANDLE_INVALID;
        AZAC_THROW_ON_FAIL(ai_core_properties_handle_create(&handle));
        AZAC_THROW_ON_FAIL(ai_core_properties_string_set(handle, 0, "adapter.streams.count", std::to_string(formats.size()).c_str()));

        for (auto format : formats)
        {
            auto targetNamespace = std::string("adapter.streams.");
            targetNamespace += std::to_string(i++);
            targetNamespace += ".";

            auto formatPropsHandle = ProtectedAccess<Frames::FrameFormatProperties>::HandleFromPtr(&format->Properties);
            AZAC_THROW_ON_FAIL(ai_core_properties_copy(formatPropsHandle, handle, targetNamespace.c_str()));
        }

        return FromHandle(handle);
    }

    /// <summary>
     /// Gets a collection of additional Frame properties.
     /// </summary>
    FrameSetFormatProperties& Properties;

protected:

    static std::shared_ptr<FrameSetFormat> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new FrameSetFormat(handle);
        return std::shared_ptr<FrameSetFormat>(ptr);
    }

    explicit FrameSetFormat(AZAC_HANDLE handle) :
        m_properties(handle, [](auto propshandle, auto* properties) { *properties = propshandle; return AZAC_ERR_NONE; }),
        Properties(m_properties)
    {
    }

    explicit operator AZAC_HANDLE() { return (AZAC_HANDLE)ProtectedAccess<Frames::FrameSetFormatProperties>::HandleFromPtr(&m_properties); }
};

} } } } } // Azure::AI::Vision::Input::Frames
