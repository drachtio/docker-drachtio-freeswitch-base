//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_result_event_args_base.h>
//#include <vision_api_cxx_face_result.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Face {
namespace Events {

/// <summary>
/// Represents inference recognition event arguments.
/// </summary>
class FaceAnalyzedResultEventArgs : private Core::Details::ResultEventArgsBase<Results::FaceAnalyzedResult, int>
{
private:

    using BaseResultEventArgs = Core::Details::ResultEventArgsBase<Results::FaceAnalyzedResult, int>;

public:

    /// <summary>
    /// Gets the Result of an AI inteferening operation
    /// </summary>
    /// <returns>The FaceAnalyzedResult wrapped inside a std::shared_ptr</returns>
    std::shared_ptr<Results::FaceAnalyzedResult> GetResult() const { return BaseResultEventArgs::GetResult(); }

protected:

    static std::shared_ptr<FaceAnalyzedResultEventArgs> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new FaceAnalyzedResultEventArgs(handle);
        return std::shared_ptr<FaceAnalyzedResultEventArgs>(ptr);
    }

    explicit FaceAnalyzedResultEventArgs(AZAC_HANDLE eventArgs) : ResultEventArgsBase(eventArgs)
    {
    }

private:

    AZAC_DISABLE_DEFAULT_CTORS(FaceAnalyzedResultEventArgs);
};

} } } } } // Azure::AI::Vision::Face::Events
