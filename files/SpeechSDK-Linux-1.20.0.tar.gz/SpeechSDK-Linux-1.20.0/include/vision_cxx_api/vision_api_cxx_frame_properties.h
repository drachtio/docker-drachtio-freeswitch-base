//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_frame_property.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Input {
namespace Frames {

/// <summary>
/// Represents the collection of properties on a given Frame
/// </summary>
class FrameProperties : private AI::Core::Details::PropertyCollectionBase<Frames::FrameProperty>
{
private:
    template<typename Target>
    using ProtectedAccess = Azure::AI::Core::Details::ProtectedAccess<Target>;
    using PropertyCollection = AI::Core::Details::PropertyCollectionBase<Frames::FrameProperty>;

public:
    using PropertyCollection::Set;
    using PropertyCollection::Get;

protected:
    FrameProperties(AZAC_HANDLE handle) : PropertyCollection(handle) {}
    explicit operator AZAC_HANDLE() { return ProtectedAccess<PropertyCollection>::HandleFromPtr(this); }
};

} } } } } // Azure::AI::Vision::Input::Frames
