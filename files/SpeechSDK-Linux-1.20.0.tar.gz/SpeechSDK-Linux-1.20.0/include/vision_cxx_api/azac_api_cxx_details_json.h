//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_c_json.h>
#include <azac_api_cxx_common.h>
#include <memory>

// TODO: TFS#3671215 - Vision: C/C++ azac_api* files are in shared include directory, speech and vision share

/*! \cond INTERNAL */

namespace Azure {
namespace AI {
namespace Core {
namespace Details {
namespace Json {

enum ValueKind {
    Error = -1,
    End = 0,
    Object = '{',
    Array = '[',
    String = '\"',
    Number = '1',
    Boolean = 'b',
    Null = 'n',
    Unspecified = '?'
};

class JsonValue {
public:
    static JsonValue Parse(const char* json, size_t jsize)
    {
        AZAC_HANDLE handle;
        int root = ai_core_json_parser_create(&handle, json, jsize);
        AZAC_IFTRUE_THROW_HR(root < 0, AZAC_ERR_INVALID_ARG);

        std::shared_ptr<_azac_empty> parser(handle, ai_core_json_parser_handle_release);

        return JsonValue {parser, root};
    }

    JsonValue operator[](int index) const
    {
        int newItem = ai_core_json_item_at(parser.get(), item, index, nullptr);
        AZAC_IFTRUE_THROW_HR(newItem < 0, AZAC_ERR_NOT_FOUND);

        return JsonValue {parser, newItem};
    }

    JsonValue operator[](const char* key) const
    {
        int newItem = ai_core_json_item_at(parser.get(), item, 0, key);
        AZAC_IFTRUE_THROW_HR(newItem < 0, AZAC_ERR_NOT_FOUND);

        return JsonValue {parser, newItem};
    }

    bool HasValue(int index) const
    {
        return ai_core_json_item_at(parser.get(), item, index, nullptr) >= 0;
    }

    bool HasValue(const char* key) const
    {
        return ai_core_json_item_at(parser.get(), item, 0, key) >= 0;
    }

    int Count() const
    {
        return ai_core_json_item_count(parser.get(), item);
    }

    ValueKind Kind() const
    {
        return static_cast<ValueKind>(ai_core_json_value_kind(parser.get(), item));
    }

    std::string AsString() const
    {
        const char* value = ai_core_json_value_as_string_copy(parser.get(), item, nullptr);
        AZAC_IFTRUE_THROW_HR(value == nullptr, AZAC_ERR_INVALID_ARG);
        std::string result = value;
        ai_core_string_free(value);

        return result;
    }

    int64_t AsInt() const
    {
        AZAC_IFFALSE_THROW_HR(Kind() == ValueKind::Number, AZAC_ERR_INVALID_ARG);
        return ai_core_json_value_as_int(parser.get(), item, 0);
    }

    uint64_t AsUInt() const
    {
        AZAC_IFFALSE_THROW_HR(Kind() == ValueKind::Number, AZAC_ERR_INVALID_ARG);
        return ai_core_json_value_as_uint(parser.get(), item, 0);
    }

    double AsDouble() const
    {
        AZAC_IFFALSE_THROW_HR(Kind() == ValueKind::Number, AZAC_ERR_INVALID_ARG);
        return ai_core_json_value_as_double(parser.get(), item, 0.0);
    }

    float AsFloat() const
    {
        return static_cast<float>(AsDouble());
    }

    bool AsBool() const
    {
        AZAC_IFFALSE_THROW_HR(Kind() == ValueKind::Boolean, AZAC_ERR_INVALID_ARG);
        return ai_core_json_value_as_bool(parser.get(), item, false);
    }

private:

    JsonValue(std::shared_ptr<_azac_empty> parser, int item)
        : parser(parser), item(item)
    {}

    std::shared_ptr<_azac_empty> parser;
    int item;
};

} } } } } // Azure::AI::Core::Details::Json

/*! \endcond */
