//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_event_args_base.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Details {

template<typename TPropKey>
class SessionEventArgsBase : public EventArgsBase<TPropKey>
{
public:

    std::string GetSessionId() const
    {
        return EventArgsBase<TPropKey>::Get("session.id", "");
    }

    template<class T = std::string> 
    AI::Core::Details::enable_if_w_or_string_t<T> GetSessionId() const
    {
        return AI::Core::Details::to_string<T>(EventArgsBase<TPropKey>::Get("session.id", ""));
    }

protected:

    explicit SessionEventArgsBase(AZAC_HANDLE eventArgs) : EventArgsBase<TPropKey>(eventArgs)
    {
    }

private:

    AZAC_DISABLE_DEFAULT_CTORS(SessionEventArgsBase);
};

} } } } } // Azure::AI::Vision::Core::Details
