//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_c_common.h>

// TODO: TFS#3671215 - Vision: C/C++ azac_api* files are in shared include directory, speech and vision share

AZAC_API_(bool) ai_core_properties_handle_is_valid(AZAC_HANDLE properties);
AZAC_API ai_core_properties_handle_create(AZAC_HANDLE* properties);
AZAC_API ai_core_properties_handle_release(AZAC_HANDLE properties);

AZAC_API__(const char*) ai_core_properties_string_get(AZAC_HANDLE properties, int id, const char* name, const char* defaultValue);
AZAC_API ai_core_properties_string_set(AZAC_HANDLE properties, int id, const char* name, const char* value);
AZAC_API ai_core_properties_string_free(const char* value);

AZAC_API__(const char*) ai_core_properties_string_matches_get(AZAC_HANDLE properties, const char* pattern, bool searchParent);

AZAC_API ai_core_properties_copy(AZAC_HANDLE fromProperties, AZAC_HANDLE toProperties, const char* targetNamespace);

AZAC_API ai_core_properties_json_reader_get(AZAC_HANDLE properties, int id, const char* name, AZAC_HANDLE* reader, int* item);
