//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>
#include <array>

namespace Azure {
namespace AI {
namespace Vision {
namespace Body {
namespace Results {

enum JointConfidenceLevel
{
    ///
    /// <summary>
    ///     The joint is out of range (too far from depth camera)
    /// </summary>
    None = 0,
    ///
    /// <summary>
    ///     The joint is not observed (likely due to occlusion), predicted joint pose
    /// </summary>
    Low = 1,
    ///
    /// <summary>
    ///     Medium confidence in joint pose. Current SDK will only provide joints up to this
    ///     confidence level
    /// </summary>
    Medium = 2,
    ///
    /// <summary>
    ///     High confidence in joint pose. Placeholder for future SDK
    /// </summary>
    High = 3,
};

enum JointId {
    ///
    /// <summary>
    ///     Pelvis
    /// </summary>
    Pelvis = 0,
    ///
    /// <summary>
    ///     Spine navel
    /// </summary>
    SpineNavel = 1,
    ///
    /// <summary>
    ///     Spine chest
    /// </summary>
    SpineChest = 2,
    ///
    /// <summary>
    ///     Neck
    /// </summary>
    Neck = 3,
    ///
    /// <summary>
    ///     Left clavicle
    /// </summary>
    ClavicleLeft = 4,
    ///
    /// <summary>
    ///     Left shoulder
    /// </summary>
    ShoulderLeft = 5,
    ///
    /// <summary>
    ///     Left elbow
    /// </summary>
    ElbowLeft = 6,
    ///
    /// <summary>
    ///     Left wrist
    /// </summary>
    WristLeft = 7,
    ///
    /// <summary>
    ///     Left hand
    /// </summary>
    HandLeft = 8,
    ///
    /// <summary>
    ///     Left hand tip
    /// </summary>
    HandTipLeft = 9,
    ///
    /// <summary>
    ///     Left thumb
    /// </summary>
    ThumbLeft = 10,
    ///
    /// <summary>
    ///     Right clavicle
    /// </summary>
    ClavicleRight = 11,
    ///
    /// <summary>
    ///     Right shoulder
    /// </summary>
    ShoulderRight = 12,
    ///
    /// <summary>
    ///     Right elbow
    /// </summary>
    ElbowRight = 13,
    ///
    /// <summary>
    ///     Right wrist
    /// </summary>
    WristRight = 14,
    ///
    /// <summary>
    ///     Right hand
    /// </summary>
    HandRight = 15,
    ///
    /// <summary>
    ///     Right hand tip
    /// </summary>
    HandTipRight = 16,
    ///
    /// <summary>
    ///     Right thumb
    /// </summary>
    ThumbRight = 17,
    ///
    /// <summary>
    ///     Left hip
    /// </summary>
    HipLeft = 18,
    ///
    /// <summary>
    ///     Left knee
    /// </summary>
    KneeLeft = 19,
    ///
    /// <summary>
    ///     Left ankle
    /// </summary>
    AnkleLeft = 20,
    ///
    /// <summary>
    ///     Left foot
    /// </summary>
    FootLeft = 21,
    ///
    /// <summary>
    ///     Right hip
    /// </summary>
    HipRight = 22,
    ///
    /// <summary>
    ///     Right knee
    /// </summary>
    KneeRight = 23,
    ///
    /// <summary>
    ///     Right ankle
    /// </summary>
    AnkleRight = 24,
    ///
    /// <summary>
    ///     Right foot
    /// </summary>
    FootRight = 25,
    ///
    /// <summary>
    ///     Head
    /// </summary>
    Head = 26,
    ///
    /// <summary>
    ///     Nose
    /// </summary>
    Nose = 27,
    ///
    /// <summary>
    ///     Left eye
    /// </summary>
    EyeLeft = 28,
    ///
    /// <summary>
    ///     Left ear
    /// </summary>
    EarLeft = 29,
    ///
    /// <summary>
    ///     Right eye
    /// </summary>
    EyeRight = 30,
    ///
    /// <summary>
    ///     Right ear
    /// </summary>
    EarRight = 31
};

// TODO: TFS#3677030 - Vision: Vector3... should be generic, or specific or in Vision::Body namespace?
union Vector3
{
    // XYZ or array representation of vector
    struct _xyz
    {
        float X;
        float Y;
        float Z;
    } XYZ;       // < X, Y, Z representation of a vector
    float V[3];  // < Array representation of a vector
};

// TODO: TFS#3677032 - Vision: Quaternion... should be generic, or specific or in Vision::Body namespace?
typedef union
{
    // WXYZ or array representation of quaternion
    struct _wxyz
    {
        float W;
        float X;
        float Y;
        float Z;
    } WXYZ;      // < W, X, Y, Z representation of a quaternion
    float V[4];  // < Array representation of a quaternion
} Quaternion;

struct Joint
{
    /// <summary>
    ///     The position of the joint specified in millimeters.
    /// </summary>
    Vector3 Position;

    /// <summary>
    ///     The orientation of the joint specified in normalized quaternion.
    /// </summary>
    Quaternion Orientation;

    /// <summary>
    ///     The confidence level of the joint.
    /// </summary>
    JointConfidenceLevel ConfidenceLevel;
};

struct Skeleton
{
    static constexpr int JointCount = 32;

    /// <summary>
    ///     The array of Joints, indexed by JointId
    /// </summary>
    std::array<Joint, JointCount> Joints;
};

struct Body
{
    /// <summary>
    ///     The body ID for a particular person
    /// </summary>
    uint32_t Id;

    /// <summary>
    /// The Skeleton for a particular person, which contains the joint information
    /// </summary>
    Results::Skeleton Skeleton;
};


} } } } } // Azure::AI::Vision::Body::Results
