//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_c_common.h>

AZAC_API_(bool) vision_frame_format_handle_is_valid(AZAC_HANDLE format);
AZAC_API vision_frame_format_handle_create(AZAC_HANDLE* format, char ch1, char ch2, char ch3, char ch4, AZAC_HANDLE moreOptions);
AZAC_API vision_frame_format_handle_release(AZAC_HANDLE format);

AZAC_API vision_frame_format_properties_handle_get(AZAC_HANDLE format, AZAC_HANDLE* properties);
