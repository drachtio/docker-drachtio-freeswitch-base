//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once

#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_event_signal.h>
#include <vision_api_cxx_body_tracker.h>
#include <vision_api_cxx_body_tracking_error_details.h>
#include <vision_api_cxx_body_tracker_options.h>
#include <vision_api_cxx_body_tracking_event_args.h>
#include <vision_api_cxx_body_tracking_result.h>
#include <vision_api_cxx_body_tracking_stop_details.h>
#include <vision_api_cxx_console_logger.h>
#include <vision_api_cxx_event_logger.h>
#include <vision_api_cxx_face_analyzer.h>
#include <vision_api_cxx_face_session_stopped_error_details.h>
#include <vision_api_cxx_face_session_stopped_details.h>
#include <vision_api_cxx_file_logger.h>
#include <vision_api_cxx_frame.h>
#include <vision_api_cxx_frame_format.h>
#include <vision_api_cxx_frame_source.h>
#include <vision_api_cxx_frame_writer.h>
#include <vision_api_cxx_frameset_format.h>
#include <vision_api_cxx_frameset_source.h>
#include <vision_api_cxx_frameset_writer.h>
#include <vision_api_cxx_memory_logger.h>
#include <vision_api_cxx_session_options.h>
#include <vision_api_cxx_session_recognizer.h>
#include <vision_api_cxx_session_result.h>
#include <vision_api_cxx_session_result_event_args.h>
#include <vision_api_cxx_session_result_reason.h>
#include <vision_api_cxx_service_config.h>
#include <vision_api_cxx_session_started_event_args.h>
#include <vision_api_cxx_session_stopped_event_args.h>
#include <vision_api_cxx_session_stopped_error_details.h>
#include <vision_api_cxx_session_stopped_details.h>
#include <vision_api_cxx_session.h>
#include <vision_api_cxx_session_options.h>
#include <vision_api_cxx_source.h>
