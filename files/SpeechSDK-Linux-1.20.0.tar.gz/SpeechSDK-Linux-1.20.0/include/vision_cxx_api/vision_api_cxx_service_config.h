//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_service_advanced_options.h>
#include <vision_api_cxx_service_option.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Service {

/// <summary>
/// Represents the service configuration options and parameters used to connect to network attached
/// AI inferencing technologies over IP based protocols.
/// </summary>
/// <remarks>Use VisionServiceConfig::FromEndpoint() or similar to instantiate</remarks>
class VisionServiceConfig
{
private:

    template<typename Target> using ProtectedAccess = ::Azure::AI::Core::Details::ProtectedAccess<Target>;
    std::shared_ptr<VisionServiceAdvancedOptions> m_options;

public:

    /// <summary>
    /// Initializes a new instance of the VisionServiceConfig class used to connect to the specified URL endpoint.
    /// </summary>
    /// <param name="endpoint">The vision service endpoint to connect to.</param>
    /// <returns>The newly created VisionServiceConfig wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<VisionServiceConfig> FromEndpoint(const std::string& endpoint)
    {
        auto ptr = new VisionServiceConfig();
        ptr->Advanced.Set("service.endpoint", endpoint.c_str());

        return std::shared_ptr<VisionServiceConfig>(ptr);
    }

    /// <summary>
    /// Initializes a new instance of the VisionServiceConfig class used to connect to the specified URL endpoint.
    /// </summary>
    /// <param name="endpoint">The vision service endpoint to connect to.</param>
    /// <param name="key">The API key for the vision service.</param>
    /// <returns>The newly created VisionServiceConfig wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<VisionServiceConfig> FromEndpoint(const std::string& endpoint, const std::string& key)
    {
        auto ptr = new VisionServiceConfig();
        ptr->Advanced.Set("service.endpoint", endpoint.c_str());
        ptr->Advanced.Set("service.auth.key", key.c_str());

        return std::shared_ptr<VisionServiceConfig>(ptr);
    }

    /// <summary>
    /// Initializes a new instance of the VisionServiceConfig class used to connect to the specified URL endpoint.
    /// </summary>
    /// <param name="endpoint">The vision service endpoint to connect to.</param>
    /// <returns>The newly created VisionServiceConfig wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<VisionServiceConfig> FromEndpoint(const std::wstring& endpoint)
    {
        return FromEndpoint(AI::Core::Details::to_string<std::string>(endpoint));
    }

    /// <summary>
    /// Initializes a new instance of the VisionServiceConfig class used to connect to the specified URL endpoint.
    /// </summary>
    /// <param name="endpoint">The vision service endpoint to connect to.</param>
    /// <param name="key">The API key for the vision service.</param>
    /// <returns>The newly created VisionServiceConfig wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<VisionServiceConfig> FromEndpoint(const std::wstring& endpoint, const std::wstring& key)
    {
        return FromEndpoint(
            AI::Core::Details::to_string<std::string>(endpoint),
            AI::Core::Details::to_string<std::string>(key));
    }

    /// <summary>
    /// Sets the authorization token to be used to connect to the service.
    /// </summary>
    /// <param name="token">The authorization token</param>
    void SetAuthorizationToken(const std::string& token)
    {
        Advanced.Set("service.auth.token", token);
    }

    /// <summary>
    /// Sets the authorization token to be used to connect to the service.
    /// </summary>
    /// <param name="token">The authorization token</param>
    void SetAuthorizationToken(const std::wstring& token)
    {
        SetAuthorizationToken(AI::Core::Details::to_string<std::string>(token));
    }

    /// <summary>
    /// Destructs an instance of the VisionServiceConfig class.
    /// </summary>
    virtual ~VisionServiceConfig() = default;

    /// <summary>
    /// Advanced options and parameters
    /// </summary>
    VisionServiceAdvancedOptions& Advanced;

    // TODO: TFS#3664466 - Vision: What VisionServiceConfig strongly typed methods go here?

protected:

    explicit VisionServiceConfig() :
        m_options(ProtectedAccess<VisionServiceAdvancedOptions>::Create()),
        Advanced(*m_options.get())
    {
    }

    explicit operator AZAC_HANDLE()
    {
        return ProtectedAccess<VisionServiceAdvancedOptions>::HandleFromPtr(m_options.get());
    }

private:

    AZAC_DISABLE_COPY_AND_MOVE(VisionServiceConfig);
};

} } } } // Azure::AI::Vision::Service
