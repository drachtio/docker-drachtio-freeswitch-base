//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <future>
#include <azac_api_c_async_op.h>
#include <azac_api_c_properties.h>
#include <azac_api_cxx_common.h>
#include <azac_api_cxx_details_promise_callback_helper.h>
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_c_session.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_event_signal.h>
#include <vision_api_cxx_service_config.h>
#include <vision_api_cxx_session_options.h>
#include <vision_api_cxx_session_properties.h>
#include <vision_api_cxx_session_property.h>
#include <vision_api_cxx_session_result.h>
#include <vision_api_cxx_session_result_event_args.h>
#include <vision_api_cxx_session_started_event_args.h>
#include <vision_api_cxx_session_stopped_event_args.h>
#include <vision_api_cxx_source.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Session {

/// <summary>
/// Represents a set of Vision capabilities used for a finite period of time, with a given set of configuration, input, and options
/// </summary>
class VisionSession : public std::enable_shared_from_this<VisionSession>
{
protected:

    template<typename Target> using ProtectedAccess = Azure::AI::Core::Details::ProtectedAccess<Target>;
    AI::Core::Details::PropertyCollection<Session::VisionSessionProperty, Session::VisionSessionProperties> m_properties;

public:

    /// <summary>
    /// Initializes a new instance of the VisionSession class.
    /// </summary>
    /// <returns>The newly created VisionSession wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<VisionSession> Create(const std::shared_ptr<Service::VisionServiceConfig>& config, const std::shared_ptr<Input::VisionSource>& input, const std::shared_ptr<Options::VisionSessionOptions>& options = nullptr)
    {
        auto allOptions = AI::Core::Details::PropertyCollection<>::Create();
        AZAC_HANDLE combinedOptions = ProtectedAccess<AI::Core::Details::PropertyCollectionBase<>>::HandleFromPtr(allOptions.get());
        AZAC_HANDLE configHandle = ProtectedAccess<Service::VisionServiceConfig>::HandleFromPtr(config.get());
        AZAC_HANDLE optionsHandle = ProtectedAccess<Options::VisionSessionOptions>::HandleFromPtr(options.get());

        AZAC_IFTRUE(configHandle != nullptr, AZAC_THROW_ON_FAIL(ai_core_properties_copy(configHandle, combinedOptions, NULL)));
        AZAC_IFTRUE(optionsHandle != nullptr, AZAC_THROW_ON_FAIL(ai_core_properties_copy(optionsHandle, combinedOptions, NULL)));

        AZAC_HANDLE session = AZAC_HANDLE_INVALID;
        AZAC_HANDLE sourceHandle = ProtectedAccess<Input::VisionSource>::HandleFromPtr(input.get());
        AZAC_THROW_ON_FAIL(::vision_session_handle_create(&session, combinedOptions, sourceHandle));
        auto ptr = FromHandle(session);

        AZAC_THROW_ON_FAIL(vision_session_view_event_callback_set(session, "session.started", ptr.get(), SessionEventCallbackHandler));
        AZAC_THROW_ON_FAIL(vision_session_view_event_callback_set(session, "session.stopped", ptr.get(), SessionEventCallbackHandler));
        AZAC_THROW_ON_FAIL(vision_session_view_event_callback_set(session, "recognized", ptr.get(), SessionEventCallbackHandler));

        return ptr;
    }

    /// <summary>
    /// Destructs an instance of the VisionSession class.
    /// </summary>
    virtual ~VisionSession()
    {
        if (vision_session_handle_is_valid(m_session))
        {
            ::vision_session_handle_release(m_session);
            m_session = AZAC_HANDLE_INVALID;
        }
    };

    /// <summary>
    /// Gets the unique Session ID from which this VisionSession originated.
    /// </summary>
    /// <returns>
    /// The Session ID string.
    /// </returns>
    std::string GetSessionId() const
    {
        return m_properties.Get("session.id", "");
    }

    /// <summary>
    /// Gets the unique Session ID from which this VisionSession originated.
    /// </summary>
    /// <returns>
    /// The Session ID string.
    /// </returns>
    template<class T = std::string>
    AI::Core::Details::enable_if_w_or_string_t<T> GetSessionId() const
    {
        return AI::Core::Details::to_string<T>(m_properties.Get("session.id", ""));
    }

    /// <summary>
    /// Recognize one SessionResult from the input.
    /// </summary>
    /// <returns>The newly created SessionResult wrapped inside a std::shared_ptr</returns>
    std::shared_ptr<Results::SessionResult> RecognizeOnce()
    {
        auto timeout = GetMillisecondTimeout("session.recognize.once", 60000);

        AZAC_HANDLE asyncOp = AZAC_HANDLE_INVALID;
        AZAC_THROW_ON_FAIL(vision_session_view_single_shot_start(m_session, nullptr, nullptr, &asyncOp));

        AZAC_HANDLE result = AZAC_HANDLE_INVALID;
        auto waited = async_op_wait_for_result(asyncOp, timeout, &result);
        AZAC_THROW_ON_FAIL(async_op_handle_release(asyncOp));

        auto recognized = VZ_SUCCEEDED(waited)
            ? ProtectedAccess<Results::SessionResult>::FromHandle(result)
            : GetRecognizeOnceWaitFailedResult(waited);

        return recognized;
    }

    /// <summary>
    /// Recognize one SessionResult from the input, asynchronously.
    /// </summary>
    /// <returns>The future SessionResult wrapped inside a std::future<std::shared_ptr<>></returns>
    std::future<std::shared_ptr<Results::SessionResult>> RecognizeOnceAsync()
    {
        auto promiseResult = std::make_shared<std::promise<std::shared_ptr<Results::SessionResult>>>();
        auto promiseAsyncOp = std::make_shared<std::promise<AZAC_HANDLE>>();

        auto asyncOpCallback = m_promises.PromiseAsyncOpCallback(shared_from_this(), nullptr, [=](int /* id */, AZAC_HANDLE /* asyncOpCallback */) {

            auto asyncOp = promiseAsyncOp->get_future().get();

            AZAC_HANDLE result = AZAC_HANDLE_INVALID;
            auto waited = async_op_wait_for_result(asyncOp, 0, &result);
            AZAC_REPORT_ON_FAIL(async_op_handle_release(asyncOp));

            auto recognized = VZ_SUCCEEDED(waited)
                ? ProtectedAccess<Results::SessionResult>::FromHandle(result)
                : GetRecognizeOnceWaitFailedResult(waited);

            promiseResult->set_value(recognized);
        });

        AZAC_HANDLE asyncOp = AZAC_HANDLE_INVALID;
        auto check = vision_session_view_single_shot_start(m_session, nullptr, asyncOpCallback, &asyncOp);

        if (AZAC_FAILED(check))
        {
            AZAC_REPORT_ON_FAIL(async_op_callback_handle_release(asyncOpCallback));
            AZAC_THROW_HR(check);
        }

        promiseAsyncOp->set_value(asyncOp);
        return promiseResult->get_future();
    }

    /// <summary>
    /// Starts recognizing Results from the input, continuously.
    /// </summary>
    void StartContinuousRecognition()
    {
        auto timeout = GetMillisecondTimeout("session.start.continuous.recognition", 60000);

        AZAC_HANDLE asyncOp = AZAC_HANDLE_INVALID;
        AZAC_THROW_ON_FAIL(vision_session_view_continuous_start(m_session, nullptr, nullptr, &asyncOp));

        auto waited = async_op_wait_for(asyncOp, timeout);
        AZAC_THROW_ON_FAIL(async_op_handle_release(asyncOp));
        AZAC_THROW_ON_FAIL(waited);
    }

    /// <summary>
    /// Starts recognizing Results from the input, continuously.
    /// </summary>
    /// <returns>A std::future<void> to be completed once continuous recognition has started</returns>
    std::future<void> StartContinuousRecognitionAsync()
    {
        auto promise = std::make_shared<std::promise<void>>();
        auto asyncOpCallback = m_promises.PromiseAsyncOpCallback(shared_from_this(), std::move(promise));

        AZAC_HANDLE asyncOp = AZAC_HANDLE_INVALID;
        auto check = vision_session_view_continuous_start(m_session, nullptr, asyncOpCallback, &asyncOp);
        AZAC_REPORT_ON_FAIL(async_op_handle_release(asyncOp));

        AZAC_IFTRUE(AZAC_FAILED(check), AZAC_REPORT_ON_FAIL(async_op_callback_handle_release(asyncOpCallback)));
        AZAC_THROW_ON_FAIL(check);

        return promise->get_future();
    }

    /// <summary>
    /// Stops recognizing Results from the input
    /// </summary>
    void StopContinuousRecognition()
    {
        auto timeout = GetMillisecondTimeout("session.stop.continuous.recognition", 60000);

        AZAC_HANDLE asyncOp = AZAC_HANDLE_INVALID;
        AZAC_THROW_ON_FAIL(vision_session_view_continuous_stop(m_session, nullptr, nullptr, &asyncOp));

        auto waited = async_op_wait_for(asyncOp, timeout);
        AZAC_THROW_ON_FAIL(async_op_handle_release(asyncOp));
        AZAC_THROW_ON_FAIL(waited);
    }

    /// <summary>
    /// Stops recognizing Results from the input, asynchronously.
    /// </summary>
    /// <returns>A std::future<void> to be completed once continuous recognition has stopped</returns>
    std::future<void> StopContinuousRecognitionAsync()
    {
        auto promise = std::make_shared<std::promise<void>>();
        auto asyncOpCallback = m_promises.PromiseAsyncOpCallback(shared_from_this(), std::move(promise));

        AZAC_HANDLE asyncOp = AZAC_HANDLE_INVALID;
        auto check = vision_session_view_continuous_stop(m_session, nullptr, asyncOpCallback, &asyncOp);
        AZAC_REPORT_ON_FAIL(async_op_handle_release(asyncOp));

        AZAC_IFTRUE(AZAC_FAILED(check), AZAC_REPORT_ON_FAIL(async_op_callback_handle_release(asyncOpCallback)));
        AZAC_THROW_ON_FAIL(check);

        return promise->get_future();
    }

    /// <summary>
    /// Waits for recognition to stop
    /// </summary>
    /// <returns>true if the session stopped, false if not stopped after, the default timeout</returns>
    /// <remarks>WaitForStop does not initiate stopping. Call StopContinuousRecognition or similar to initiate stopping</remarks>
    bool WaitForStop()
    {
        auto timeout = std::chrono::milliseconds(GetMillisecondTimeout("session.wait.for.stop", 60000));
        return WaitForStop(timeout);
    }

    /// <summary>
    /// Waits for recognition to stop
    /// </summary>
    /// <returns>true if the session stopped, false if not stopped after timeout</returns>
    /// <remarks>WaitForStop does not initiate stopping. Call StopContinuousRecognition or similar to initiate stopping</remarks>
    bool WaitForStop(const std::chrono::milliseconds& timeout)
    {
        auto future = WaitForStopAsync();
        auto status = future.wait_for(timeout);
        return status == std::future_status::ready;
    }

    /// <summary>
    /// Waits for recognition to stop
    /// </summary>
    /// <returns>std::future<bool> representing the session stopping</returns>
    /// <remarks>WaitForStop does not initiate stopping. Call StopContinuousRecognition or similar to initiate stopping</remarks>
    std::future<void> WaitForStopAsync()
    {
        auto stoppedPromise = std::make_shared<std::promise<void>>();

        if (m_started.load())
        {    
            m_promises.PromiseCallback(shared_from_this(), "session.stopped", std::move(stoppedPromise), [=](int id, AZAC_HANDLE /* handle */) {
                m_promises.RemovePromiseCallback(id, "session.stopped");
                });
        }
        else
        {
            stoppedPromise->set_value();
        }

        return stoppedPromise->get_future();
    }

    /// <summary>
    /// Signal for events indicating the start of a recognition session (operation).
    /// </summary>
    Core::Events::EventSignal<const Events::SessionStartedEventArgs&> SessionStarted;

    /// <summary>
    /// Signal for events indicating the end of a recognition session (operation).
    /// </summary>
    Core::Events::EventSignal<const Events::SessionStoppedEventArgs&> SessionStopped;

    /// <summary>
    /// Signal for events containing recognition operations.
    /// </summary>
    Core::Events::EventSignal<const Events::SessionResultEventArgs&> Recognized;

    /// <summary>
    /// Gets a collection of additional inferencing operation properties.
    /// </summary>
    Session::VisionSessionProperties& Properties;

protected:

    static std::shared_ptr<VisionSession> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new VisionSession(handle);
        return std::shared_ptr<VisionSession>(ptr);
    }

    explicit VisionSession(AZAC_HANDLE session) :
        m_properties(session, [](auto handle, auto* properties) { return vision_session_properties_handle_get(handle, properties); }),
        Properties(m_properties),
        m_session(session)
    {
    }

    explicit operator AZAC_HANDLE() { return m_session; }

    uint32_t GetMillisecondTimeout(const char* prefix, int defaultMilliseconds)
    {
        auto name = std::string(prefix) + ".timeout.milliseconds";
        auto value = m_properties.Get(name, std::to_string(defaultMilliseconds));
        return std::stoi(value);
    }

    std::shared_ptr<Results::SessionResult> GetRecognizeOnceWaitFailedResult(AZACHR waited)
    {
        auto timeout = GetMillisecondTimeout("session.recognize.once.wait.failed.stop.timeout", 2000);

        AZAC_HANDLE asyncOp = AZAC_HANDLE_INVALID;
        AZAC_REPORT_ON_FAIL(vision_session_view_single_shot_stop(m_session, nullptr, nullptr, &asyncOp));
        AZAC_REPORT_ON_FAIL(async_op_wait_for(asyncOp, timeout));
        AZAC_REPORT_ON_FAIL(async_op_handle_release(asyncOp));

        return GetWaitFailedResult(waited);
    }

    std::shared_ptr<Results::SessionResult> GetWaitFailedResult(AZACHR waited)
    {
        return waited == AZAC_ERR_TIMEOUT
            ? GetWaitTimedoutResult()
            : GetWaitErrorResult(waited);
    }

    std::shared_ptr<Results::SessionResult> GetWaitTimedoutResult()
    {
        // TODO: TFS#3664100 - Vision: RecognizeOnce timeout/failed results implementation and tests
        return std::shared_ptr<Results::SessionResult>(nullptr);
    }

    std::shared_ptr<Results::SessionResult> GetWaitErrorResult(AZACHR waited)
    {
        UNUSED(waited); // TODO: TFS#3664100 - Vision: RecognizeOnce timeout/failed results implementation and tests
        return std::shared_ptr<Results::SessionResult>(nullptr);
    }

    static void SessionEventCallbackHandler(AZAC_HANDLE session, const char* name, void* context, AZAC_HANDLE eventArgs)
    {
        auto ptr = static_cast<VisionSession*>(context);
        ptr->m_promises.CompletePromiseCallbacks(name, eventArgs);

        AZAC_IFTRUE(strcmp(name, "session.started") == 0, ptr->SessionStartedCallback(session, context, eventArgs));
        AZAC_IFTRUE(strcmp(name, "session.stopped") == 0, ptr->SessionStoppedCallback(session, context, eventArgs));
        AZAC_IFTRUE(strcmp(name, "recognized") == 0, ptr->RecognizedCallback(session, context, eventArgs));
    }

    void SessionStartedCallback(AZAC_HANDLE session, void* context, AZAC_HANDLE eventArgs)
    {
        UNUSED(session); UNUSED(context);

        auto startedBefore = m_started.exchange(true);
        AZAC_DBG_ASSERT(!startedBefore); UNUSED(startedBefore);

        auto connected = SessionStarted.IsConnected();
        AZAC_IFTRUE_RETURN(!connected);

        auto ptr = ProtectedAccess<Events::SessionStartedEventArgs>::FromHandle(eventArgs);
        SessionStarted.Signal(*ptr.get());
    }

    void SessionStoppedCallback(AZAC_HANDLE session, void* context, AZAC_HANDLE eventArgs)
    {
        UNUSED(session); UNUSED(context);

        auto startedBefore = m_started.exchange(false);
        AZAC_DBG_ASSERT(startedBefore); UNUSED(startedBefore);

        auto connected = SessionStopped.IsConnected();
        AZAC_IFTRUE_RETURN(!connected);

        auto ptr = ProtectedAccess<Events::SessionStoppedEventArgs>::FromHandle(eventArgs);
        SessionStopped.Signal(*ptr.get());
    }

    void RecognizedCallback(AZAC_HANDLE session, void* context, AZAC_HANDLE eventArgs)
    {
        UNUSED(session); UNUSED(context);

        auto connected = Recognized.IsConnected();
        AZAC_IFTRUE_RETURN(!connected);

        auto ptr = ProtectedAccess<Events::SessionResultEventArgs>::FromHandle(eventArgs);
        Recognized.Signal(*ptr.get());
    }

private:

    AZAC_DISABLE_DEFAULT_CTORS(VisionSession);

    AZAC_HANDLE m_session;
    std::atomic_bool m_started { false };
    AI::Core::Details::PromiseCallbackHelper<VisionSession> m_promises;
};

} } } } } // Azure::AI::Vision::Core::Session
