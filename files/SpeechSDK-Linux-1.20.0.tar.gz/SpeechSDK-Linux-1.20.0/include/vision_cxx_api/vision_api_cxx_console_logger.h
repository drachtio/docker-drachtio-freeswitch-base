//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_c_diagnostics.h>
#include <vision_api_cxx_common.h>
#include <string>
#include <sstream>
#include <iostream>
#include <iterator>
#include <vector>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Diagnostics {
namespace Logging {

/// <summary>
/// Represents the ability of the SDK to log to the console.
/// </summary>
class ConsoleLogger
{
public:
    /// <summary>
    /// Starts console logging
    /// </summary>
    /// <param name="logToStderr">true to log to stderr, false for stdout</param>
    static void Start(bool logToStderr = true)
    {
        diagnostics_log_console_start_logging(logToStderr);
    }

    /// <summary>
    /// Stops console logging
    /// </summary>
    static void Stop()
    {
        diagnostics_log_console_stop_logging();
    }

    /// <summary>
    /// Sets filters for console logging.
    /// </summary>
    /// <param name="filters">Filters to use</param>
    static void SetFilters(std::initializer_list<const char*> filters)
    {
        std::ostringstream filtersCollapsed;
        std::copy(filters.begin(), filters.end(), std::ostream_iterator<std::string>(filtersCollapsed, ";"));

        diagnostics_log_console_set_filters(filtersCollapsed.str().c_str());
    }
};

}}}}}}
