//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_frame_properties.h>
#include <vision_api_cxx_frame_property.h>
#include <vision_api_c_frame_format.h>
#include <vision_api_c_frame.h>
#include <cstring>

namespace Azure {
namespace AI {
namespace Vision {
namespace Input {
namespace Frames {

/// <summary>
/// Represents a frame
/// </summary>
class Frame
{
protected:
    bool m_ownsDataBuffer = false;
    AZAC_HANDLE m_frameHandle = AZAC_HANDLE_INVALID;

    AI::Core::Details::PropertyCollection<Frames::FrameProperty, Frames::FrameProperties> m_properties;

public:
    ~Frame()
    {
        if (m_ownsDataBuffer)
        {
            ai_core_free_buffer(Data);
        }

        if (AZAC_HANDLE_INVALID != m_frameHandle)
        {
            vision_frame_handle_release(m_frameHandle);
            m_frameHandle = AZAC_HANDLE_INVALID;
        }
    }

    /// <summary>
    /// Create a Frame that wraps a data buffer owned by the caller.
    /// </summary>
    static std::shared_ptr<Frame> Create(const uint8_t* data, size_t dataSizeInBytes)
    {
        auto ptr = new Frame(data, dataSizeInBytes);
        return std::shared_ptr<Frame>(ptr);
    }

    /// <summary>
    /// Create a Frame that copies the data buffer provided by the caller.
    /// </summary>
    static std::shared_ptr<Frame> CreateWithDataCopy(const uint8_t* data, size_t dataSizeInBytes)
    {
        uint8_t* dataCopy = ai_core_allocate_buffer(dataSizeInBytes);
        AZAC_IFTRUE_THROW_HR(nullptr == dataCopy, AZAC_ERR_OUT_OF_MEMORY);

        std::memcpy(dataCopy, data, dataSizeInBytes);
        auto ptr = new Frame(dataCopy, dataSizeInBytes, true /* takeDataBufferOwnership */);
        return std::shared_ptr<Frame>(ptr);
    }

    /// <summary>
    /// Gets a collection of additional Frame properties.
    /// </summary>
    FrameProperties& Properties;

    const uint8_t* Data;
    const size_t DataSizeInBytes;

protected:
    static std::shared_ptr<Frame> FromHandle(AZAC_HANDLE frameHandle)
    {
        auto ptr = new Frame(frameHandle);
        return std::shared_ptr<Frame>(ptr);
    }

    explicit Frame(AZAC_HANDLE frameHandle) :
        m_frameHandle(frameHandle),
        m_properties(frameHandle, [](auto handle, auto* properties) { return vision_frame_properties_handle_get(handle, properties); }),
        Properties(m_properties),
        Data(nullptr),
        DataSizeInBytes(0)
    {
        Data = vision_frame_get_data(frameHandle, const_cast<size_t*>(&DataSizeInBytes));
    }

    explicit Frame(const uint8_t* data, size_t dataSizeInBytes, bool takeDataBufferOwnership = false) :
        m_ownsDataBuffer(takeDataBufferOwnership),
        m_properties(nullptr, [](auto handle, auto* properties) { UNUSED(handle);  return ai_core_properties_handle_create(properties); }),
        Properties(m_properties),
        Data(data),
        DataSizeInBytes(dataSizeInBytes)
    {}


    // TODO: TFS#3664421 - Once we have ref-counted shared memory semantics for the WriteFrame scenario, this can return the frameHandle
    explicit operator AZAC_HANDLE() { return (AZAC_HANDLE)AI::Core::Details::ProtectedAccess<Frames::FrameProperties>::HandleFromPtr(&m_properties); }

};

} } } } } // Azure::AI::Vision::Input::Frames
