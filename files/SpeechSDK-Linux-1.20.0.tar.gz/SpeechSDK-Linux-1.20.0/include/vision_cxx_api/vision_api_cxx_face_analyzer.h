//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <future>
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_event_signal.h>
#include <vision_api_cxx_details_recognizer_base.h>
#include <vision_api_cxx_face_analysis_options.h>
#include <vision_api_cxx_face_analyzer_create_options.h>
#include <vision_api_cxx_face_analyzer_properties.h>
#include <vision_api_cxx_face_analyzer_property.h>
#include <vision_api_cxx_face_analyzing_result.h>
#include <vision_api_cxx_face_analyzing_result_event_args.h>
#include <vision_api_cxx_face_analyzed_result.h>
#include <vision_api_cxx_face_analyzed_result_event_args.h>
#include <vision_api_cxx_face_session_started_event_args.h>
#include <vision_api_cxx_face_session_stopped_event_args.h>
#include <vision_api_cxx_session.h>
#include <vision_api_cxx_source.h>

namespace Azure {
    namespace AI {
        namespace Vision {
            namespace Face {

                // TODO: TFS#3425716 - Vision: Ensure Face APIs are documented in C++ ref docs

                /// <summary>
                /// Represents a set of Vision capabilities used for a finite period of time, with a given set of configuration, input, and options
                /// </summary>
                /// <remarks>Use FaceAnalyzer::Create(service, input) to instantiate</remarks>
                class FaceAnalyzer :
                    public std::enable_shared_from_this<FaceAnalyzer>,
                    private Core::Details::RecognizerBase<Face::FaceAnalyzer,
                    Options::FaceAnalyzerCreateOptions, Options::FaceAnalyzerCreateOption,
                    Options::FaceAnalysisOptions, Options::FaceAnalysisOption,
                    Face::FaceAnalyzerProperties, Face::FaceAnalyzerProperty,
                    Results::FaceAnalyzedResult, Events::FaceAnalyzedResultEventArgs,
                    Results::FaceAnalyzingResult, Events::FaceAnalyzingResultEventArgs,
                    Events::FaceSessionStartedEventArgs, Events::FaceSessionStoppedEventArgs>
                {
                protected:

                    friend class Core::Details::RecognizerBase<FaceAnalyzer,
                        Options::FaceAnalyzerCreateOptions, Options::FaceAnalyzerCreateOption,
                        Options::FaceAnalysisOptions, Options::FaceAnalysisOption,
                        Face::FaceAnalyzerProperties, Face::FaceAnalyzerProperty,
                        Results::FaceAnalyzedResult, Events::FaceAnalyzedResultEventArgs,
                        Results::FaceAnalyzingResult, Events::FaceAnalyzingResultEventArgs,
                        Events::FaceSessionStartedEventArgs, Events::FaceSessionStoppedEventArgs>;

                    using BaseRecognizer = Core::Details::RecognizerBase<FaceAnalyzer,
                        Options::FaceAnalyzerCreateOptions, Options::FaceAnalyzerCreateOption,
                        Options::FaceAnalysisOptions, Options::FaceAnalysisOption,
                        Face::FaceAnalyzerProperties, Face::FaceAnalyzerProperty,
                        Results::FaceAnalyzedResult, Events::FaceAnalyzedResultEventArgs,
                        Results::FaceAnalyzingResult, Events::FaceAnalyzingResultEventArgs,
                        Events::FaceSessionStartedEventArgs, Events::FaceSessionStoppedEventArgs>;

                public:

                    /// <summary>
                    /// Initializes a new instance of the FaceAnalyzer class.
                    /// </summary>
                    /// <param name="config">service configuration</param>
                    /// <param name="input">input video source</param>
                    /// <param name="options">creation parameters</param>
                    /// <returns>The newly created FaceAnalyzer wrapped inside a std::shared_ptr</returns>
                    static std::shared_ptr<FaceAnalyzer> Create(const std::shared_ptr<Service::VisionServiceConfig>& config, const std::shared_ptr<Input::VisionSource>& input, const std::shared_ptr<Options::FaceAnalyzerCreateOptions>& options = nullptr)
                    {
                        return BaseRecognizer::Create("face.analyzer", config, input, options);
                    }

                    /// <summary>
                    /// Destructs an instance of the FaceAnalyzer class.
                    /// </summary>
                    virtual ~FaceAnalyzer() { }

                    /// <summary>
                    /// Gets the unique Session ID for this FaceAnalyzer.
                    /// </summary>
                    /// <returns>
                    /// The Session ID string.
                    /// </returns>
                    std::string GetSessionId() const { return BaseRecognizer::GetSessionId(); }

                    /// <summary>
                    /// Gets the unique Session ID for this FaceAnalyzer.
                    /// </summary>
                    /// <returns>
                    /// The Session ID string.
                    /// </returns>
                    template<class T = std::string>
                    AI::Core::Details::enable_if_w_or_string_t<T> GetSessionId() const { return BaseRecognizer::GetSessionId<T>(); }

                    /// <summary>
                    /// Analyze one FaceAnalyzedResult from the input.
                    /// </summary>
                    /// <param name="options">Optional options for performing analysis.</param>
                    /// <returns>The newly created FaceAnalyzedResult wrapped inside a std::shared_ptr</returns>
                    std::shared_ptr<Results::FaceAnalyzedResult> AnalyzeOnce(const std::shared_ptr<Options::FaceAnalysisOptions>& options = nullptr) { return BaseRecognizer::RecognizeOnce(options); }

                    /// <summary>
                    /// Analyze one FaceAnalyzedResult from the input, asynchronously.
                    /// </summary>
                    /// <param name="options">Optional options for performing analysis.</param>
                    /// <returns>The future FaceAnalyzedResult wrapped inside a std::future<std::shared_ptr<>></returns>
                    std::future<std::shared_ptr<Results::FaceAnalyzedResult>> AnalyzeOnceAsync(const std::shared_ptr<Options::FaceAnalysisOptions>& options = nullptr) { return BaseRecognizer::RecognizeOnceAsync(options); }

                    /// <summary>
                    /// Stops analyzing Results from the input.
                    /// </summary>
                    void StopAnalyzeOnce() { BaseRecognizer::StopRecognitionOnce(); }

                    /// <summary>
                    /// Stops analyzing Results from the input, asynchronously.
                    /// </summary>
                    /// <returns>The future FaceAnalyzedResult wrapped inside a std::future<std::shared_ptr<>></returns>
                    std::future<void> StopAnalyzeOnceAsync() { return BaseRecognizer::StopRecognitionOnceAsync(); }

                    /// <summary>
                    /// Starts analyzing Results from the input, continuously.
                    /// </summary>

                    /// <summary>
                    /// Starts analyzing Results from the input, continuously.
                    /// </summary>
                    /// <param name="options">Optional options for performing analysis.</param>
                    void StartContinuousAnalysis(const std::shared_ptr<Options::FaceAnalysisOptions>& options = nullptr) { BaseRecognizer::StartContinuousRecognition(options); }

                    /// <summary>
                    /// Starts analyzing Results from the input, continuously.
                    /// </summary>
                    /// <returns>A std::future<void> to be completed once continuous recognition has started</returns>
                    /// <param name="options">Optional options for performing analysis.</param>
                    std::future<void> StartContinuousAnalysisAsync(const std::shared_ptr<Options::FaceAnalysisOptions>& options = nullptr) { return BaseRecognizer::StartContinuousRecognitionAsync(options); }

                    /// <summary>
                    /// Stops analyzing Results from the input
                    /// </summary>
                    void StopContinuousAnalysis() { BaseRecognizer::StopContinuousRecognition(); }

                    /// <summary>
                    /// Stops analyzing Results from the input, asynchronously.
                    /// </summary>
                    /// <returns>A std::future<void> to be completed once continuous recognition has stopped</returns>
                    std::future<void> StopContinuousAnalysisAsync() { return BaseRecognizer::StopContinuousRecognitionAsync(); }

                    /// <summary>
                    /// Waits for recognition to stop
                    /// </summary>
                    /// <returns>true if the session stopped, false if not stopped after, the default timeout</returns>
                    /// <remarks>WaitForStop does not initiate stopping. Call StopContinuousAnalysis or similar to initiate stopping</remarks>
                    bool WaitForStop() { return BaseRecognizer::WaitForStop(); }

                    /// <summary>
                    /// Waits for recognition to stop
                    /// </summary>
                    /// <param name="timeout">time to wait for stop.</param>
                    /// <returns>true if the session stopped, false if not stopped after timeout</returns>
                    /// <remarks>WaitForStop does not initiate stopping. Call StopContinuousAnalysis or similar to initiate stopping</remarks>
                    bool WaitForStop(const std::chrono::milliseconds& timeout) { return BaseRecognizer::WaitForStop(timeout); }

                    /// <summary>
                    /// Waits for recognition to stop
                    /// </summary>
                    /// <returns>std::future<bool> representing the session stopping</returns>
                    /// <remarks>WaitForStop does not initiate stopping. Call StopContinuousAnalysis or similar to initiate stopping</remarks>
                    std::future<void> WaitForStopAsync() { return BaseRecognizer::WaitForStopAsync(); }

                    /// <summary>
                    /// Signal for events indicating the start of a recognition session (operation).
                    /// </summary>
                    Core::Events::EventSignal<const Events::FaceSessionStartedEventArgs&>& Started;

                    /// <summary>
                    /// Signal for events indicating the end of a recognition session (operation).
                    /// </summary>
                    Core::Events::EventSignal<const Events::FaceSessionStoppedEventArgs&>& Stopped;

                    /// <summary>
                    /// Signal for events containing intermedia recognition operations.
                    /// </summary>
                    Core::Events::EventSignal<const Events::FaceAnalyzingResultEventArgs&>& Analyzing;

                    /// <summary>
                    /// Signal for events containing recognition operations.
                    /// </summary>
                    Core::Events::EventSignal<const Events::FaceAnalyzedResultEventArgs&>& Analyzed;

                    /// <summary>
                    /// Gets a collection of additional inferencing operation properties.
                    /// </summary>
                    FaceAnalyzerProperties& Properties;

                protected:

                    explicit FaceAnalyzer(AZAC_HANDLE view) :
                        RecognizerBase(view),
                        Started(m_SessionStarted),
                        Stopped(m_SessionStopped),
                        Analyzing(m_Recognizing),
                        Analyzed(m_Recognized),
                        Properties(GetProperties())
                    {
                    }

                private:

                    AZAC_DISABLE_DEFAULT_CTORS(FaceAnalyzer);
                };

            }
        }
    }
} // Azure::AI::Vision::Face
