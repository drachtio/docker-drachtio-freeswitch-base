//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once

#include <azac_api_cxx_common.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_frame.h>
#include <vision_api_c_frame_reader.h>
#include <vision_api_cxx_frameset_reader.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Input {
namespace Frames {

/// <summary>
/// Represents the ability to read image frame data, for use as input w/ Vision AI scenario operations.
/// </summary>
class FrameReader
{
protected:
    template<typename Target> using ProtectedAccess = ::Azure::AI::Core::Details::ProtectedAccess<Target>;

public:

    /// <summary>
    /// Destructs an instance of the FrameReader class.
    /// </summary>
    virtual ~FrameReader()
    {
        if (vision_frame_reader_handle_is_valid(m_frameReaderHandle))
        {
            vision_frame_reader_handle_release(m_frameReaderHandle);
            m_frameReaderHandle = AZAC_HANDLE_INVALID;
        }
    };

    /// <summary>
    /// Reads a single frame of image data from the underlying FrameSource.
    /// </summary>
    std::shared_ptr<Frame> ReadFrame(uint64_t pos)
    {
        AZAC_HANDLE frameHandle = AZAC_HANDLE_INVALID;
        auto hr = vision_frame_reader_read_frame(m_frameReaderHandle, pos, 0, &frameHandle);
        UNUSED(hr);
        AZAC_DBG_TRACE_VERBOSE("vision_frame_reader_read_frame(m_frameReaderHandle, pos, 0, &frameHandle) returned: 0x%08x", hr);
        
        return ProtectedAccess<Frame>::FromHandle(frameHandle);
    }

protected:

    static std::shared_ptr<FrameReader> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new FrameReader(handle);
        return std::shared_ptr<FrameReader>(ptr);
    }

    explicit FrameReader(AZAC_HANDLE frameReader) :
            m_frameReaderHandle(frameReader)
    {
    }

    explicit operator AZAC_HANDLE() { return m_frameReaderHandle; }

private:

    AZAC_DISABLE_DEFAULT_CTORS(FrameReader);

    AZAC_HANDLE m_frameReaderHandle;
};

} } } } } // Azure::AI::Vision::Input::Frames
