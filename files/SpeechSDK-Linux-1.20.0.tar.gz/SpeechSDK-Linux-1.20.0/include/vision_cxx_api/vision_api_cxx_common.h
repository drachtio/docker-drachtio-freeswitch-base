//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once

#include <cstdarg>
#include <type_traits>
#include <utility>

#include <azac_api_cxx_common.h>
#include <azac_api_cxx_details_property_collection.h>
#include <azac_api_cxx_details_string_helpers.h>
#include <vision_api_c_errors.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Details {

template<typename T, typename U>
struct is_container_of
{
    static constexpr bool value = std::is_same<typename std::decay_t<T>::value_type, U>::value &&
                                  std::is_same<typename std::decay_t<T>::iterator, decltype(std::declval<T>().begin())>::value &&
                                  std::is_same<typename std::decay_t<T>::iterator, decltype(std::declval<T>().end())>::value;
};

} } } } } // Azure::AI::Vision::Core::Details

