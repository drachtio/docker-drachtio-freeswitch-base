//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once

#include <azac_api_c_common.h>

AZAC_API__(uint8_t*) ai_core_allocate_buffer(size_t size);
AZAC_API_(void) ai_core_free_buffer(const uint8_t* ptr);
