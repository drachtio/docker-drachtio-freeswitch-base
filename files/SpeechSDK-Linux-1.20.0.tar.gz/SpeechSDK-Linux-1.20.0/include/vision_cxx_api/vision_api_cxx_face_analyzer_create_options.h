//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_face_analyzer_create_option.h>
#include <vision_api_cxx_common.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Face {
namespace Options {

/// <summary>
/// Defines how the face analysis is performed.
/// </summary>
enum class FaceAnalyzerMode
{
    ///<summary>
    /// Faces are detected in each image in isolation, assuming there is no temporal context in-between each image.
    ///</summary>
    DetectFacesOnStaticImages = 1,
    ///<summary>
    /// Faces are tracked across the image-stream, assuming there is temporal context in each subsequent image in the image-stream.
    ///</summary>
    TrackFacesAcrossImageStream
};

/// <summary>
/// Defines the computations that the face analyer should perform.
/// </summary>
enum class FaceAnalyzerCreateOption
{
    ///<summary>
    /// Compute face landmarks.
    ///</summary>
    Landmarks = (int)FaceAnalyzerCreateOptionInternal::Options_Landmarks,
    ///<summary>
    /// Compute face pose.
    ///</summary>
    Pose,
    ///<summary>
    /// Perform facial recognition.
    ///</summary>
    Recognition,
    ///<summary>
    /// Perform liveness detection on face.
    ///</summary>
    Liveness
};

/// <summary>
/// Represents the options and parameters used to initialize a VisionSession instance.
/// </summary>
class FaceAnalyzerCreateOptions
{
public:

    /// <summary>
    /// Defines how the face analysis is performed.
    /// <param name="mode">The face analyzer mode.</param>
    /// </summary>
    void SetFaceAnalysisMode(FaceAnalyzerMode mode)
    {
        Advanced.m_options->Set(FaceAnalyzerCreateOptionInternal::FaceAnalyzerMode, (int)mode);
    }

    /// <summary>
    /// Defines the computations that the face analyer should perform.
    /// <param name="option">The face analyzer create option.</param>
    /// </summary>
    void SetFaceAnalyzerOptions(FaceAnalyzerCreateOption option)
    {
        Advanced.m_options->Set((FaceAnalyzerCreateOptionInternal)((int)option), true);
    }

    /// <summary>
    /// Represents advanced options and parameters used to initialize a FaceAnalyzer instance
    /// </summary>
    class AdvancedOptions
    {
    private:
        //template<typename Target> using ProtectedAccess = Azure::AI::Core::Details::ProtectedAccess<Target>;
        using PropertyCollection = AI::Core::Details::PropertyCollection<FaceAnalyzerCreateOptionInternal>;
        std::shared_ptr<PropertyCollection> m_options;

        AdvancedOptions() : m_options(PropertyCollection::Create()) {}
        friend class FaceAnalyzerCreateOptions;

    public:
        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="option">The string value's key</param>
        /// <param name="value">The new string value</param>
        void Set(const std::string& option, const char* value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="option">The string value's key</param>
        /// <param name="value">The new string value</param>
        void Set(const std::wstring& option, const wchar_t* value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="option">The string value's key</param>
        /// <param name="value">The new string value</param>
        void Set(const std::string& option, const std::string& value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="option">The string value's key</param>
        /// <param name="value">The new string value</param>
        void Set(const std::wstring& option, const std::wstring& value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property boolean value for the specified key value.
        /// </summary>
        /// <param name="option">The boolean value's key</param>
        /// <param name="value">The new boolean value</param>
        void Set(const std::string& option, bool value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property boolean value for the specified key value.
        /// </summary>
        /// <param name="option">The boolean value's key</param>
        /// <param name="value">The new boolean value</param>
        void Set(const std::wstring& option, bool value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property integer value for the specified key value.
        /// </summary>
        /// <param name="option">The integer value's key</param>
        /// <param name="value">The new integer value</param>
        void Set(const std::string& option, int value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property integer value for the specified key value.
        /// </summary>
        /// <param name="option">The integer value's key</param>
        /// <param name="value">The new integer value</param>
        void Set(const std::wstring& option, int value)
        {
            m_options->Set(option, value);
        }
    };

private:

    template<typename Target> using ProtectedAccess = Azure::AI::Core::Details::ProtectedAccess<Target>;
    using PropertyCollection = AI::Core::Details::PropertyCollection<FaceAnalyzerCreateOptionInternal>;

public:

    /// <summary>
    /// Initializes a new instance of the FaceAnalyzerCreateOptions class.
    /// </summary>
    /// <returns>The newly created FaceAnalyzerCreateOptions wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<FaceAnalyzerCreateOptions> Create()
    {
        auto ptr = new FaceAnalyzerCreateOptions();
        return std::shared_ptr<FaceAnalyzerCreateOptions>(ptr);
    }

    /// <summary>
    /// Destructs an instance of the FaceAnalyzerCreateOptions class.
    /// </summary>
    ~FaceAnalyzerCreateOptions() = default;

    AdvancedOptions Advanced;

protected:

    explicit FaceAnalyzerCreateOptions() 
    {
    }

    explicit operator AZAC_HANDLE()
    {
        return ProtectedAccess<PropertyCollection>::HandleFromPtr(Advanced.m_options.get());
    }

private:

    AZAC_DISABLE_COPY_AND_MOVE(FaceAnalyzerCreateOptions);
};

} } } } } // Azure::AI::Vision::Face::Options
