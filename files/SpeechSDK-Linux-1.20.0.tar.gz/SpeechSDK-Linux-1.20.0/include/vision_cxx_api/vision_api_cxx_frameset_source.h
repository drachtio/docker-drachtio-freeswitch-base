//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_c_frame_source.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_frameset_format.h>
#include <vision_api_cxx_frameset_source_properties.h>
#include <vision_api_cxx_frameset_source_property.h>
#include <vision_api_cxx_frameset_writer.h>
#include <vision_api_cxx_frameset_reader.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Input {
namespace Frames {

/// <summary>
/// Represents a source of image frame data, used as input (or output) to (or from) Vision AI scenario operations.
/// </summary>
class FrameSetSource
{
protected:

    template<typename Target> using ProtectedAccess = ::Azure::AI::Core::Details::ProtectedAccess<Target>;
    AI::Core::Details::PropertyCollection<Frames::FrameSetSourceProperty, Frames::FrameSetSourceProperties> m_properties;

public:

    using CallbackFunction_Type = ::std::function<void(const std::shared_ptr<FrameSetWriter>& writer)>;

    /// <summary>
    /// Initializes a new instance of the FrameSetSource class.
    /// </summary>
    /// <param name="format">A FrameSetFormat obtained via FrameSetFormat::Create() or similar</param>
    /// <returns>The newly created FrameSetSource wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<FrameSetSource> FromFormat(const std::shared_ptr<FrameSetFormat>& format)
    {
        AZAC_HANDLE handle = AZAC_HANDLE_INVALID;
        AZAC_HANDLE formatHandle = ProtectedAccess<FrameSetFormat>::HandleFromPtr(format.get());

        AZAC_THROW_ON_FAIL(::vision_frame_source_handle_create(&handle, nullptr, nullptr, formatHandle, nullptr));
        return FromHandle(handle);
    }

    /// <summary>
    /// Initializes a new instance of the FrameSetSource class.
    /// </summary>
    /// <param name="format">A FrameSetFormat obtained via FrameSetFormat::Create() or similar</param>
    /// <param name="callback">TODO</param>
    /// <returns>The newly created FrameSetSource wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<FrameSetSource> FromFormat(const std::shared_ptr<FrameSetFormat>& format, CallbackFunction_Type callback)
    {
        AZAC_HANDLE handle = AZAC_HANDLE_INVALID;
        AZAC_HANDLE formatHandle = ProtectedAccess<FrameSetFormat>::HandleFromPtr(format.get());
       
        AZAC_THROW_ON_FAIL(::vision_frame_source_handle_create(&handle, nullptr, nullptr, formatHandle, nullptr));

        
        return FromHandle(handle, callback);
    }

    /// <summary>
    /// Destructs an instance of the FrameSetSource class.
    /// </summary>
    virtual ~FrameSetSource()
    {
        if (vision_frame_source_handle_is_valid(m_frameSource))
        {
            ::vision_frame_source_handle_release(m_frameSource);
            m_frameSource = AZAC_HANDLE_INVALID;
        }
    };

    /// <summary>
    /// Gets the FrameWriter used to write frame data into this FrameSetSource object
    /// </summary>
    /// <returns>The FrameWriter used to write frame data, wrapped inside a std::shared_ptr</returns>
    std::shared_ptr<FrameSetWriter> GetWriter()
    {
        AZAC_HANDLE handle = AZAC_HANDLE_INVALID;
        AZAC_THROW_ON_FAIL(vision_frame_source_writer_handle_get(m_frameSource, &handle));
        return ProtectedAccess<FrameSetWriter>::FromHandle(handle);
    }

    /// <summary>
    /// Gets the FrameReader used to read frame data from this FrameSetSource object
    /// </summary>
    /// <returns>The FrameReader used to read frame data, wrapped inside a std::shared_ptr</returns>
    std::shared_ptr<FrameSetReader> GetReader()
    {
        AZAC_HANDLE handle = AZAC_HANDLE_INVALID;
        AZAC_THROW_ON_FAIL(vision_frame_source_reader_handle_get(m_frameSource, &handle));
        return ProtectedAccess<FrameSetReader>::FromHandle(handle);
    }

    /// <summary>
    /// Gets a collection of additional FrameSetSource properties.
    /// </summary>
    FrameSetSourceProperties& Properties;

protected:

    static std::shared_ptr<FrameSetSource> FromHandle(AZAC_HANDLE handle, CallbackFunction_Type callback = nullptr)
    {
        auto ptr = new FrameSetSource(handle, callback);
        return std::shared_ptr<FrameSetSource>(ptr);
    }
    
    explicit FrameSetSource(AZAC_HANDLE frameSource, CallbackFunction_Type callback) :
        m_properties(frameSource, [](auto handle, auto* properties) { return vision_frame_source_properties_handle_get(handle, properties); }),
        Properties(m_properties),
        m_frameSource(frameSource),
        m_callback(callback)
    {
        if (nullptr != m_callback)
        {
            vision_frame_source_callback_set(m_frameSource, this, FrameSetSource::NotifyCallback);
        }
    }

    explicit operator AZAC_HANDLE() { return m_frameSource; }

private:

    AZAC_DISABLE_DEFAULT_CTORS(FrameSetSource);

    AZAC_HANDLE m_frameSource;
    CallbackFunction_Type m_callback;

    static void NotifyCallback(AZAC_HANDLE handle, void* context)
    {
        UNUSED(handle);
        FrameSetSource* targetSource = (FrameSetSource*)context;
        targetSource->m_callback(targetSource->GetWriter());
    }
};

} } } } } // Azure::AI::Vision::Input::Frames
