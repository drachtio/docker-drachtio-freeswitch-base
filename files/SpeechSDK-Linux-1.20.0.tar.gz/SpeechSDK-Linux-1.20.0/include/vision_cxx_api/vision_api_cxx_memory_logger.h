//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_c_diagnostics.h>
#include <vision_api_cxx_common.h>
#include <string>
#include <sstream>
#include <iostream>
#include <iterator>
#include <vector>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Diagnostics {
namespace Logging {

/// <summary>
/// Represents an in-memory buffer of SDK trace messages
/// </summary>
class MemoryLogger
{
public:
    /// <summary>
    /// Starts the internal buffer.
    /// </summary>
    static void Start()
    {
        diagnostics_log_memory_start_logging();
    }

    /// <summary>
    /// Stops the internal buffer.
    /// </summary>
    static void Stop()
    {
        diagnostics_log_memory_stop_logging();
    }

    /// <summary>
    /// Writes the content of the buffer to the specified file.
    /// </summary>
    /// <param name="filePath">File location to write to.</param>
    static void Dump(const char* filePath)
    {
        diagnostics_log_memory_dump(filePath, nullptr, false, false);
    }

    /// <summary>
    /// Writes the content of the buffer to the specified stream.
    /// </summary>
    /// <param name="outStream">Stream to write to.</param>
    static void Dump(std::ostream& outStream)
    {
        auto start = diagnostics_log_memory_get_line_num_oldest();
        auto stop = diagnostics_log_memory_get_line_num_newest();
        for (auto i = start;
            i < stop;
            i++)
        {
            outStream << diagnostics_log_memory_get_line(i);
        }
    }

    /// <summary>
    /// Returns a vector for the memory buffer
    /// </summary>
    /// <returns>A vector with the contents of the memory buffer copied into it.</returns>
    static std::vector<std::string> Dump()
    {
        std::vector<std::string> results;

        auto start = diagnostics_log_memory_get_line_num_oldest();
        auto stop = diagnostics_log_memory_get_line_num_newest();
        for (auto i = start;
            i < stop;
            i++)
        {
            results.push_back(diagnostics_log_memory_get_line(i));
        }

        return results;
    }
};

}}}}}}
