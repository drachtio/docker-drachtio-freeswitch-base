//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once

#include <type_traits>
#include <string>

#include <azac_api_c_pal.h>
#include <azac_api_cxx_common.h>

// TODO: TFS#3671215 - Vision: C/C++ azac_api* files are in shared include directory, speech and vision share

/*! \cond INTERNAL */

namespace Azure {
namespace AI {
namespace Core {

namespace Details {

template <typename T>
using enable_if_string_t = typename std::enable_if_t<std::is_same<T, std::string>::value, std::string>;

template <typename T>
using enable_if_wstring_t = typename std::enable_if_t<std::is_same<T, std::wstring>::value, std::wstring>;

template <typename T>
using enable_if_w_or_string_t = typename std::enable_if_t<std::is_same<T, std::string>::value || std::is_same<T, std::wstring>::value, T>;

template<typename T1, typename T2 = std::string>
inline enable_if_string_t<T1> to_string(const enable_if_string_t<T2>& value)
{
    return value;
}

template<typename T1, typename T2 = std::wstring>
inline enable_if_wstring_t<T1> to_string(const enable_if_wstring_t<T2>& value)
{
    return value;
}

template<typename T1>
inline enable_if_string_t<T1> to_string(const std::wstring& value)
{
    const auto size = pal_wstring_to_string(nullptr, value.c_str(), 0);
    auto buffer = std::make_unique<std::string::value_type[]>(size);
    pal_wstring_to_string(buffer.get(), value.c_str(), size);
    return std::string{ buffer.get() };
}

template<typename T1>
inline enable_if_wstring_t<T1> to_string(const std::string& value)
{
    const auto size = pal_string_to_wstring(nullptr, value.c_str(), 0);
    auto buffer = std::make_unique<std::wstring::value_type[]>(size);
    pal_string_to_wstring(buffer.get(), value.c_str(), size);
    return std::wstring{ buffer.get() };
}

} // Details

} } } // Azure::AI::Core

/*! \endcond */
