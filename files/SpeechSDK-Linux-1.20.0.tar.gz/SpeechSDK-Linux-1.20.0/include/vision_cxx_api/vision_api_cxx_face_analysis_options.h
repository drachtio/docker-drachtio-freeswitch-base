//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <initializer_list>
#include <numeric>
#include <ostream>
#include <string>
#include <vector>
#include <vision_api_cxx_source.h>
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_face_analysis_option.h>
#include <vision_api_cxx_common.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Face {
namespace Options {

/// <summary>
/// Defines if any filtering needs to be done when multiple faces are seen in the field of view.
/// </summary>
enum class FaceSelectionMode
{
    /// <summary>
    /// All faces seen in the field of view should be analyzed.
    /// </summary>
    All,
    /// <summary>
    /// Only the largest face seen should be analyzed.
    /// During a "TrackFacesAcrossImageStream" scenario the largest face seen initially would be analyzed until face tracking is lost.
    /// </summary>
    Largest
};

/// <summary>
/// The recognition model to use (note that specifying a person group implies the same model be used)
/// </summary>
enum class RecognitionModel
{
    Recognition_01,
    Recognition_02,
    Recognition_03,
    Recognition_04,
    Latest
};

/// <summary>
/// Defines the liveness operation mode used during an "analysis" operation.
/// </summary>
enum class LivenessOperationMode
{
    /// <summary>
    /// Specifies that a liveness classfication would be more balanced, this mode is suitable for scenarios that prioritizes user experience over security.
    /// </summary>
    Balanced,

    /// <summary>
    /// Specifies that a liveness classfication would be more restrictive, this mode is suitable for scenarios that prioritizes security over user experience.
    /// </summary>
    Restrictive
};

/// <summary>
/// Represents the options and parameters used start an analysis operation.
/// </summary>
class FaceAnalysisOptions
{
public:
    /// <summary>
    /// Configures FaceAnalyzer to operate on all faces in frames versus only the largest face.
    /// </summary>
    /// <param name="mode">The mode to use in analysis to select identification, verification, etc.</param>
    void SetFaceSelectionMode(FaceSelectionMode mode)
    {
        m_options->Set(FaceAnalysisOption::FaceSelectionMode, (int)mode);
    }

    /// <summary>
    /// Configures FaceAnalyzer to identify people enrolled in given personGroupId.
    /// </summary>
    /// <param name="personGroupId">The name of the person group to use when identifying.</param>
    void SetRecognitionSearchScope(const std::string& personGroupId)
    {
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_PersonGroupId, personGroupId);
    }

    /// <summary>
    /// Configures FaceAnalyzer to identify people enrolled in given personGroupId.
    /// </summary>
    /// <param name="personGroupId">The name of the person group to use when identifying.</param>
    void SetRecognitionSearchScope(const std::wstring& personGroupId)
    {
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_PersonGroupId, personGroupId);
    }

    /// <summary>
    /// Configures FaceAnalyzer to verify against personId, who is enrolled in personGroupId.
    /// </summary>
    /// <param name="personGroupId">The name of the person group to use.</param>
    /// <param name="personId">The person identity in the group to verify against.</param>
    void SetRecognitionSearchScope(const std::string& personGroupId, const std::string& personId)
    {
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_PersonGroupId, personGroupId);
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_PersonIds, personId);
    }

    /// <summary>
    /// Configures FaceAnalyzer to verify against personId, who is enrolled in personGroupId.
    /// </summary>
    /// <param name="personGroupId">The name of the person group to use.</param>
    /// <param name="personId">The person identity in the group to verify against.</param>
    void SetRecognitionSearchScope(const std::wstring& personGroupId, const std::wstring& personId)
    {
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_PersonGroupId, personGroupId);
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_PersonIds, personId);
    }

    /*/// <summary>
    /// Configures FaceAnalyzer to identify people enrolled in given dynamicPersonGroupId
    /// using the specified model for the identification (in case people have been enrolled with multiple models).
    /// </summary>
    void SetRecognitionSearchScope(const std::string& dynamicPersonGroupId, RecognitionModel model)
    {
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_DynamicPersonGroupId, dynamicPersonGroupId);
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_RecognitionModel, (int)model);
    }

    /// <summary>
    /// Configures FaceAnalyzer to identify people enrolled in given dynamicPersonGroupId
    /// using the specified model for the identification (in case people have been enrolled with multiple models).
    /// </summary>
    void SetRecognitionSearchScope(const std::wstring& dynamicPersonGroupId, RecognitionModel model)
    {
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_DynamicPersonGroupId, dynamicPersonGroupId);
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_RecognitionModel, (int)model);
    }

    /// <summary>
    /// Configures FaceAnalyzer to identify people among given personIds using the model.
    /// </summary>
    void SetRecognitionSearchScope(const std::vector<std::string>& personIds, RecognitionModel model)
    {
        static const char* PersonIdDelimeter = ";";
        std::string persons = std::accumulate(personIds.begin(), personIds.end(), std::string(),
            [](const std::string& ss, const std::string& s)
            {
                return ss.empty() ? s : ss + PersonIdDelimeter + s;
            });

        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_PersonIds, persons);
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_RecognitionModel, (int)model);
    }

    /// <summary>
    /// Configures FaceAnalyzer to identify people among given personIds using the model.
    /// </summary>
    void SetRecognitionSearchScope(std::initializer_list<std::string> personIds, RecognitionModel model)
    {
        static const char* PersonIdDelimeter = ";";
        std::string persons = std::accumulate(personIds.begin(), personIds.end(), std::string(),
            [](const std::string& ss, const std::string& s)
            {
                return ss.empty() ? s : ss + PersonIdDelimeter + s;
            });

        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_PersonIds, persons);
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_RecognitionModel, (int)model);
    }


    /// <summary>
    /// Configures FaceAnalyzer to identify people among given personIds using the model.
    /// </summary>
    void SetRecognitionSearchScope(const std::vector<std::wstring>& personIds, RecognitionModel model)
    {
        static const wchar_t* PersonIdDelimeter = L";";
        std::wstring persons = std::accumulate(personIds.begin(), personIds.end(), std::wstring(),
            [](const std::wstring& ss, const std::wstring& s)
            {
                return ss.empty() ? s : ss + PersonIdDelimeter + s;
            });

        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_PersonIds, persons);
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_RecognitionModel, (int)model);
    }

    /// <summary>
    /// Configures FaceAnalyzer to identify people among given personIds using the model.
    /// </summary>
    void SetRecognitionSearchScope(std::initializer_list<std::wstring> personIds, RecognitionModel model)
    {
        static const wchar_t* PersonIdDelimeter = L";";
        std::wstring persons = std::accumulate(personIds.begin(), personIds.end(), std::wstring(),
            [](const std::wstring& ss, const std::wstring& s)
            {
                return ss.empty() ? s : ss + PersonIdDelimeter + s;
            });

        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_PersonIds, persons);
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_RecognitionModel, (int)model);
    }
    */

    /// <summary>
    /// Configures FaceAnalyzer to verify against the largest face in the first image of the vision source using
    /// given recognition model.
    /// </summary>
    void SetRecognitionSearchScope(const std::shared_ptr<Input::VisionSource>& referenceFace, RecognitionModel model)
    {
        m_options->Set(FaceAnalysisOption::RecognitionSearchScope_RecognitionModel, (int)model);
        // pass through image via handle to vision source.
        m_options->m_referenceFace = referenceFace;
    }

    /// <summary>
    /// Represents the options and parameters used start an analysis operation.
    /// </summary>
    class AdvancedOptions
    {
    private:
        friend class FaceAnalysisOptions;
        template<typename Target> using ProtectedAccess = Azure::AI::Core::Details::ProtectedAccess<Target>;
        using PropertyCollection = AI::Core::Details::PropertyCollection<FaceAnalysisOption>;
        std::shared_ptr<PropertyCollection> m_options;
        std::shared_ptr<Input::VisionSource> m_referenceFace;

    public:

        /// <summary>
        /// Defines the similarity confidence of 0 to 1 of whether two face images belong to the same person.
        /// By default a face is matched if the similarity confidence is greater than or equal to 0.5.
        /// This can be used to override the default behavior to fine-tune the recognition result based on the target scenario.
        /// </summary>
        /// <param name="threshold">Minimum confidence threshold for recognition.</param>
        void SetRecognitionThreshold(float threshold)
        {
            m_options->Set(FaceAnalysisOption::AdvancedOption_RecognitionThreshold, threshold);
        }

        /// <summary>
        /// Overrides the liveness operation mode used during an "analysis" operation.
        /// </summary>
        /// <param name="mode">Liveness mode to use.</param>
        void SetLivenessOperationMode(LivenessOperationMode mode)
        {
            m_options->Set(FaceAnalysisOption::AdvancedOption_LivenessOperationMode, (int)mode);
        }

        /// <summary>
        /// Specifies the maximum amount of time to wait to see a face in the camera stream after an "analyze once" method is invoked.
        /// </summary>
        /// <param name="timeoutMilliseconds">See function name.</param>
        void SetWaitForFaceTrackingTimeoutDuringAnalyzeOnceInMilliseconds(int timeoutMilliseconds)
        {
            m_options->Set(FaceAnalysisOption::AdvancedOption_WaitForFaceTrackingTimeoutDuringAnalyzeOnceInMilliSeconds, timeoutMilliseconds);
        }

        /// <summary>
        /// Specifies the maximum amount of time to wait in frames to see a face in the camera stream after an "analyze once" method is invoked.
        /// </summary>
        /// <param name="timeoutFrames">See function name.</param>
        void SetWaitForFaceTrackingTimeoutDuringAnalyzeOnceInFrames(int timeoutFrames)
        {
            m_options->Set(FaceAnalysisOption::AdvancedOption_WaitForFaceTrackingTimeoutDuringAnalyzeOnceInFrames, timeoutFrames);
        }

        /// <summary>
        /// Sets the int value for the specified option.
        /// </summary>
        /// <param name="option">The option key</param>
        /// <param name="value">The new int value</param>
        void Set(FaceAnalysisOption option, int value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="option">The option key</param>
        /// <param name="value">The new string value</param>
        void Set(FaceAnalysisOption option, const std::string& value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="option">The option key</param>
        /// <param name="value">The new string value</param>
        void Set(FaceAnalysisOption option, const std::wstring& value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="option">The option key</param>
        /// <param name="value">The new string value</param>
        void Set(const std::string& option, const char* value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="option">The option key</param>
        /// <param name="value">The new string value</param>
        void Set(const std::wstring&& option, const wchar_t* value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="option">The option key</param>
        /// <param name="value">The new string value</param>
        void Set(const std::string& option, const std::string& value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="option">The option key</param>
        /// <param name="value">The new string value</param>
        void Set(const std::wstring&& option, const std::wstring&& value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property boolean value for the specified key value.
        /// </summary>
        /// <param name="option">The option key</param>
        /// <param name="value">The new boolean value</param>
        void Set(const std::string& option, bool value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property boolean value for the specified key value.
        /// </summary>
        /// <param name="option">The option key</param>
        /// <param name="value">The new boolean value</param>
        void Set(const std::wstring&& option, bool value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property integer value for the specified key value.
        /// </summary>
        /// <param name="option">The integer value's key</param>
        /// <param name="value">The new integer value</param>
        void Set(const std::string& option, int value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property integer value for the specified key value.
        /// </summary>
        /// <param name="option">The integer value's key</param>
        /// <param name="value">The new integer value</param>
        void Set(const std::wstring&& option, int value)
        {
            m_options->Set(option, value);
        }

    protected:

        static std::shared_ptr<AdvancedOptions> Create()
        {
            auto ptr = new AdvancedOptions();
            return std::shared_ptr<AdvancedOptions>(ptr);
        }

        explicit AdvancedOptions() :
            m_options(PropertyCollection::Create())
        {
        }

        explicit operator AZAC_HANDLE()
        {
            AZAC_HANDLE hOptions = ProtectedAccess<PropertyCollection>::HandleFromPtr(m_options.get());
            if (m_referenceFace)
            {   // Copy options to property collection within vision source of reference face and pass it back.
                AZAC_HANDLE hReferenceFaceProperties = ProtectedAccess<Input::VisionSourceProperties>::HandleFromPtr(&m_referenceFace->Properties);
                ai_core_properties_copy(hOptions, hReferenceFaceProperties, nullptr);
                //AZAC_HANDLE hReferenceFace = ProtectedAccess<Input::VisionSource>::HandleFromPtr(m_referenceFace.get());
                return hReferenceFaceProperties;
            }
            return hOptions;
        }

    private:

        AZAC_DISABLE_COPY_AND_MOVE(AdvancedOptions);
    };

private:

    template<typename Target> using ProtectedAccess = Azure::AI::Core::Details::ProtectedAccess<Target>;

    std::shared_ptr<AdvancedOptions> m_options;

public:

    /// <summary>
    /// Initializes a new instance of the FaceAnalysisOptions class.
    /// </summary>
    /// <returns>The newly created FaceAnalysisOptions wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<FaceAnalysisOptions> Create()
    {
        auto ptr = new FaceAnalysisOptions();
        return std::shared_ptr<FaceAnalysisOptions>(ptr);
    }

    /// <summary>
    /// Destructs an instance of the FaceAnalysisOptions class.
    /// </summary>
    ~FaceAnalysisOptions() = default;

    /// <summary>
    /// Advanced options and parameters
    /// </summary>
    AdvancedOptions& Advanced;

protected:

    explicit FaceAnalysisOptions() :
        m_options(ProtectedAccess<AdvancedOptions>::Create()),
        Advanced(*m_options.get())
    {
    }

    explicit operator AZAC_HANDLE()
    {
        return ProtectedAccess<AdvancedOptions>::HandleFromPtr(m_options.get());
    }

private:

    AZAC_DISABLE_COPY_AND_MOVE(FaceAnalysisOptions);
};

} } } } } // Azure::AI::Vision::Face::Options
