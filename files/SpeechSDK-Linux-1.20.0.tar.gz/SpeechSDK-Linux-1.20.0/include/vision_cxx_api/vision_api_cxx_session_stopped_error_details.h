//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_session_error_details.h>
#include <vision_api_cxx_session_stopped_event_args.h>
#include <vision_api_cxx_session_stopped_error_reason.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Session {
namespace Results {

using namespace Azure::AI::Vision::Core::Session::Events;
using namespace Azure::AI::Vision::Core::Details;

/// <summary>
/// Class with additional information about why a Recognition session had an error
/// </summary>
class  SessionStoppedErrorDetails:
    private Core::Details::SessionErrorDetails<SessionStoppedErrorReason, SessionStoppedEventArgs, SessionStoppedErrorDetails, SessionResult>
{
private:

    using BaseDetails = Core::Details::SessionErrorDetails<SessionStoppedErrorReason, SessionStoppedEventArgs, SessionStoppedErrorDetails, SessionResult>;

public:
    /// <summary>
    /// Creates an instance of SessionStoppedErrorDetails object from the SessionStoppedEventArgs.
    /// </summary>
    /// <param name="args">The arguments from a session that stopped for an error.</param>
    /// <returns>A shared pointer to SessionStoppedErrorDetails.</returns>
    static std::shared_ptr<SessionStoppedErrorDetails> FromEventArgs(const SessionStoppedEventArgs& args)
    {
        return BaseDetails::FromEventArgs(args);
    }

    /// <summary>
    /// Creates an instance of SessionStoppedErrorDetails object from the SessionStoppedEventArgs.
    /// </summary>
    /// <param name="args">The arguments from a session that stopped for an error.</param>
    /// <returns>A shared pointer to SessionStoppedErrorDetails.</returns>
    static std::shared_ptr<SessionStoppedErrorDetails> FromResult(std::shared_ptr<SessionResult> result)
    {
        return BaseDetails::FromResult(result);
    }

    /// <summary>
    /// The error message in case of an unsuccessful recognition (<see cref="Reason"/> is set to Error).
    /// </summary>
    std::string GetMessage() { return BaseDetails::GetMessage(); }

    /// <summary>
    /// The error message in case of an unsuccessful recognition (<see cref="Reason"/> is set to Error).
    /// </summary>
    template<class T = std::string> 
    AI::Core::Details::enable_if_w_or_string_t<T> GetMessage() { return BaseDetails::GetMessage<T>(); }

    /// <summary>
    /// Gets the error code
    /// </summary>
    int GetErrorCode() { return BaseDetails::GetErrorCode(); }

    /// <summary>
    /// Gets the reason for the error
    /// </summary>
    /// <remarks>See RecognitionErrorReason for a list of reasons</remarks>
    /// <returns></returns>
    SessionStoppedErrorReason GetReason() { return BaseDetails::GetReason(); }

protected:
    static std::shared_ptr<SessionStoppedErrorDetails> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new SessionStoppedErrorDetails(handle);
        return std::shared_ptr<SessionStoppedErrorDetails>(ptr);
    }

    explicit SessionStoppedErrorDetails(AZAC_HANDLE propertiesHandle)
        : BaseDetails(propertiesHandle) {}
    
    explicit operator AZAC_HANDLE() { return AI::Core::Details::ProtectedAccess<SessionStoppedErrorDetails>::HandleFromPtr(this); }
            
private:
    AZAC_DISABLE_DEFAULT_CTORS(SessionStoppedErrorDetails);
};

} } } } } } // Azure::AI::Vision::Core::Session::Results
