//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_session_stopped_details.h>
#include <vision_api_cxx_face_session_stopped_event_args.h>
#include <vision_api_cxx_face_session_stopped_error_reason.h>
#include <vision_api_cxx_face_session_stopped_reason.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Session {
namespace Results {

using namespace Azure::AI::Vision::Core::Events;

/// <summary>
/// Class with additional information about why a vision session had an stopped.
/// </summary>
class SessionStoppedDetails :
    private Core::Details::SessionStoppedDetails<SessionStoppedReason, SessionStoppedDetails, SessionResult>
{
private:

    using BaseDetails = Core::Details::SessionStoppedDetails<SessionStoppedReason, SessionStoppedDetails, SessionResult>;

public:

    /// <summary>
    /// Creates an instance of SessionStoppedDetails object from a SessionResult.
    /// </summary>
    /// <param name="args">The result from a session that stopped.</param>
    /// <returns>A shared pointer to SessionStoppedDetails.</returns>
    static std::shared_ptr<SessionStoppedDetails> FromResult(std::shared_ptr<SessionResult> result)
    {
        return BaseDetails::FromResult(result);
    }

    /// <summary>
    /// Gets the reason for stopping
    /// </summary>
    /// <remarks>See SessionStoppedReason for a list of reasons</remarks>
    /// <returns></returns>
    SessionStoppedReason GetReason() { return BaseDetails::GetReason(); }

protected:
    static std::shared_ptr<SessionStoppedDetails> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new SessionStoppedDetails(handle);
        return std::shared_ptr<SessionStoppedDetails>(ptr);
    }

    explicit SessionStoppedDetails(AZAC_HANDLE propertiesHandle)
        : BaseDetails(propertiesHandle) {}
    
    explicit operator AZAC_HANDLE() { return AI::Core::Details::ProtectedAccess<SessionStoppedDetails>::HandleFromPtr(this); }
            
private:
    AZAC_DISABLE_DEFAULT_CTORS(SessionStoppedDetails);
};

} } } } } } // Azure::AI::Vision::Core::Session::Results
